/**
 * ★ v1.2.12: FaceCapture — MediaPipe FaceLandmarker 面部捕捉 (查看器)
 *
 * 能力: 前置摄像头面部捕捉 → 驱动模型 头角度/眨眼/视线/口型/眉毛/嘴形.
 *
 * 资源全部本地化 (js/ffc/):
 *   vision_iife.js               — tasks-vision 0.10.14 bundle 转的 IIFE (挂 window.MPVision)
 *   vision_wasm_internal.js/.wasm — SIMD wasm 运行时
 *   face_landmarker.task         — float16 模型 (52 ARKit blendshapes + 4x4 头部矩阵)
 *   (vision_bundle.mjs 为 ESM 源, file:// 下 WebView 加载 <script type=module> 会被
 *    CORS 拦死, 故转 IIFE 普通脚本; Android WebView 全支持 SIMD, 无需 nosimd 版)
 *
 * ★ 写入位置 (拆 cubism5.min.js 实锤的管线顺序):
 *   motionManager.update → eyeBlink → saveParameters → breath → physics
 *   → pose → updateFocus() → coreModel.update()
 *   AOP internalModel.updateFocus:
 *     - 在 saveParameters 之后 → 面捕值不进参数快照, 停用即恢复, 零残留
 *       (对比: 写在 mm.update AOP 里会被紧随其后的 saveParameters 永久存下);
 *     - 在 updateFocus 视线跟随之后 → 面捕优先于鼠标视线;
 *     - 在 coreModel.update 变形之前 → 当帧渲染生效;
 *     - 在库眨眼之后 → 面捕眨眼自然覆盖库眨眼, 无打架
 *       (动作播放中库眨眼本来就跳过: `o || eyeBlink` 短路).
 *   与 DiffKit (表情/锁定) 完全正交, 互不感知.
 *
 * 检测频率 30fps (rAF 节流), 参数写入每渲染帧 (60fps), 值来自 EMA 平滑状态.
 */
(function (global) {
  'use strict';

  // ===== 配置 (★ v1.2.13 灵敏度实测调优) =====
  var CFG = {
    wasmBase: 'js/ffc/',                  // vision_wasm_internal.* 目录 (相对页面)
    modelPath: 'js/ffc/face_landmarker.task',
    detectInterval: 33,                   // ms ≈ 30fps
    smooth: 0.55,                         // EMA 系数: 0.35 太含蓄, 0.55 跟手
    blinkSmooth: 0.7,                     // 眨眼要更快
    angleGain: 2.2,                       // 头角度增益: 对镜头不会大幅转头,
                                          // 1.25 时模型几乎不动 → 2.2 (转 14° 即满参数)
    deadZone: 0.04,                       // 视线死区 (0.06 偏迟钝)
    mouthGain: 1.6,                       // smile/frown 分数峰值偏小 (0.5~0.7), 放大
    browGain: 1.4,                        // browInnerUp 同理
    neutralFrames: 20                     // 启动后前 N 帧采集中性头姿态 (校零)
  };

  var st = {
    state: 'idle',        // idle | starting | running | error
    error: '',
    supported: !!(global.navigator && global.navigator.mediaDevices &&
                  global.navigator.mediaDevices.getUserMedia && global.MPVision),
    frameCount: 0,
    neutralReady: false,
    _faceLost: false,
    // 最近一次原始检测结果 (诊断用)
    last: null,
    _listeners: [],
    _landmarker: null,
    _video: null,
    _stream: null,
    _raf: 0,
    _lastTs: 0,
    _bs: {},               // blendshape 缓存 {name:score}
    _euler: null,          // {yaw,pitch,roll} 度
    _landmarks: null,      // ★ v1.2.13 最近关键点 (隐私预览画线用)
    _canvas: null,
    _ctx: null,
    _contours: null,
    _neutral: null,        // 中性姿态
    _neutralBuf: [],
    _sm: {},               // EMA 状态
    _idx: null,            // 当前模型的参数索引表
    _cm: null,             // coreModel 引用 (AOP 里写参数用)
    _aop: null             // {im, orig} 便于换模型时重挂
  };

  function emit(ev) {
    ev = ev || {};
    for (var i = 0; i < st._listeners.length; i++) {
      try { st._listeners[i](ev); } catch (e) {}
    }
  }
  function setState(s, err) {
    st.state = s; st.error = err || '';
    emit({ type: 'state', state: s, error: st.error });
  }
  st.on = function (fn) { st._listeners.push(fn); };

  function log(m) {
    try {
      if (global.AndroidBridge && global.AndroidBridge.log) global.AndroidBridge.log('[FFC] ' + m);
      else console.log('[FFC] ' + m);
    } catch (e) {}
  }

  function clamp(v, mn, mx) { return v < mn ? mn : (v > mx ? mx : v); }

  // ===== 模型参数索引探测 (参数不存在则跳过对应通道, 模型自适应) =====
  function buildIndex(cm) {
    var want = ['ParamAngleX', 'ParamAngleY', 'ParamAngleZ',
                'ParamEyeLOpen', 'ParamEyeROpen', 'ParamEyeBallX', 'ParamEyeBallY',
                'ParamMouthOpenY', 'ParamMouthForm',
                'ParamBrowLY', 'ParamBrowRY', 'ParamBrowLForm', 'ParamBrowRForm'];
    var map = {};
    try {
      for (var i = 0; i < want.length; i++) {
        var idx = cm.getParameterIndex(want[i]);
        if (idx !== undefined && idx !== null && idx >= 0) map[want[i]] = idx;
      }
    } catch (e) {}
    return map;
  }

  // ===== blendshapes 数组 → {name: score} =====
  function bsToMap(categories) {
    var m = {};
    if (!categories) return m;
    for (var i = 0; i < categories.length; i++) {
      var c = categories[i];
      if (c && c.categoryName) m[c.categoryName] = c.score;
    }
    return m;
  }

  // ===== 4x4 矩阵 (列主序) → 头姿态欧拉角 (度) =====
  // R[c][r] = d[4c+r]; 分解 Rz(yaw)·Ry(pitch)·Rx(roll):
  //   pitch = asin(-R20), yaw = atan2(R10, R00), roll = atan2(R21, R22)
  // 方向约定: 模型 ParamAngleX 正 = 头向模型左转; 不对可改 ANGLE_SIGN_X 系数.
  function eulerFromMatrix(d) {
    if (!d || d.length < 11) return null;
    var m20 = d[2], m10 = d[1], m00 = d[0], m21 = d[6], m22 = d[10];
    // pitch 退化 (|R20|→1, ±90°) 时 yaw/roll 共线: roll 取 0, yaw 用 R12
    var pitch = Math.asin(clamp(-m20, -1, 1));
    var yaw, roll;
    if (Math.abs(m20) < 0.9999) {
      yaw = Math.atan2(m10, m00);
      roll = Math.atan2(m21, m22);
    } else {
      yaw = Math.atan2(-d[9], d[5]);   // R12, R11
      roll = 0;
    }
    return {
      yaw: yaw * 180 / Math.PI,       // 绕 Z: 摇头
      pitch: pitch * 180 / Math.PI,   // 绕 Y: 点头
      roll: roll * 180 / Math.PI      // 绕 X: 歪头
    };
  }

  // ===== 由 blendshapes + 欧拉角算各参数目标值 (0 前景后景独立, 全部已 clamp) =====
  function targets(bs, euler) {
    var t = {};
    // 头角度 (中性校零 + 增益)
    if (euler) {
      var n = st._neutral || { yaw: 0, pitch: 0, roll: 0 };
      t.ParamAngleX = clamp((euler.yaw - n.yaw) * CFG.angleGain, -30, 30);
      t.ParamAngleY = clamp((euler.pitch - n.pitch) * CFG.angleGain, -30, 30);
      t.ParamAngleZ = clamp((euler.roll - n.roll) * CFG.angleGain, -30, 30);
    }
    // 眼开闭: blink 1=闭 → 开度 1-blink; squint 收窄修正
    var bl = bs.eyeBlinkLeft || 0, br = bs.eyeBlinkRight || 0;
    var sl = bs.eyeSquintLeft || 0, sr = bs.eyeSquintRight || 0;
    t.ParamEyeLOpen = clamp((1 - bl) * (1 - 0.35 * sl), 0, 1);
    t.ParamEyeROpen = clamp((1 - br) * (1 - 0.35 * sr), 0, 1);
    // 视线: 左眼向模型左 = OutLeft, 右眼向模型左 = InRight (带死区)
    var bx = (bs.eyeLookOutLeft || 0) - (bs.eyeLookInLeft || 0)
           + (bs.eyeLookInRight || 0) - (bs.eyeLookOutRight || 0);
    var by = (bs.eyeLookUpLeft || 0) + (bs.eyeLookUpRight || 0)
           - (bs.eyeLookDownLeft || 0) - (bs.eyeLookDownRight || 0);
    bx = bx / 2; by = by / 2;
    t.ParamEyeBallX = Math.abs(bx) < CFG.deadZone ? 0 : clamp(bx, -1, 1);
    t.ParamEyeBallY = Math.abs(by) < CFG.deadZone ? 0 : clamp(by, -1, 1);
    // 口型 (★ v1.2.13: smile/frown 分数放大, 微表情更明显)
    t.ParamMouthOpenY = clamp(bs.jawOpen || 0, 0, 1);
    var smi = ((bs.mouthSmileLeft || 0) + (bs.mouthSmileRight || 0)) / 2;
    var fro = ((bs.mouthFrownLeft || 0) + (bs.mouthFrownRight || 0)) / 2;
    t.ParamMouthForm = clamp((smi - fro) * CFG.mouthGain, -1, 1);
    // 眉毛 (★ v1.2.13: 分数放大)
    var inner = (bs.browInnerUp || 0) * CFG.browGain;
    t.ParamBrowLY = clamp(inner + (bs.browOuterUpLeft || 0) * 0.4 * CFG.browGain - (bs.browDownLeft || 0) * CFG.browGain, -1, 1);
    t.ParamBrowRY = clamp(inner + (bs.browOuterUpRight || 0) * 0.4 * CFG.browGain - (bs.browDownRight || 0) * CFG.browGain, -1, 1);
    t.ParamBrowLForm = t.ParamBrowLY;
    t.ParamBrowRForm = t.ParamBrowRY;
    return t;
  }

  // ===== EMA 平滑 + 写入 coreModel (每渲染帧, 在 updateFocus AOP 里调) =====
  function ema(key, target, alpha) {
    var s = st._sm;
    if (s[key] === undefined || !isFinite(s[key])) { s[key] = target; return target; }
    s[key] = s[key] + (target - s[key]) * alpha;
    return s[key];
  }
  function applyToCore() {
    var cm = st._cm, idx = st._idx;
    if (!cm || !idx) return;
    var e = st._euler, bs = st._bs;
    if (!bs || Object.keys(bs).length === 0) return;   // 还没有检测数据
    // 中性采集期间不动头角度, 其余照常 (表情先活起来, 采集完头部再接管)
    var t = targets(bs, st.neutralReady ? e : null);
    for (var pid in idx) {
      if (!Object.prototype.hasOwnProperty.call(idx, pid)) continue;
      if (t[pid] === undefined) continue;
      var v;
      try {
        if (/^ParamAngle/.test(pid)) {
          v = ema(pid, t[pid], CFG.smooth);
        } else if (/EyeLOpen|EyeROpen/.test(pid)) {
          v = ema(pid, t[pid], CFG.blinkSmooth);
        } else {
          v = ema(pid, t[pid], CFG.smooth);
        }
        var i = idx[pid];
        var mn = cm.getParameterMinimumValue ? cm.getParameterMinimumValue(i) : -30;
        var mx = cm.getParameterMaximumValue ? cm.getParameterMaximumValue(i) : 30;
        cm.setParameterValueByIndex(i, clamp(v, mn, mx));
      } catch (e2) {}
    }
    st.out = t;
  }

  // ===== 检测循环 (30fps 节流) =====
  function loop() {
    st._raf = requestAnimationFrame(loop);
    var v = st._video;
    if (!v || v.readyState < 2 || !st._landmarker || st.state !== 'running') return;
    var now = performance.now();
    if (now - st._lastTs < CFG.detectInterval) return;
    st._lastTs = now;
    try {
      var res = st._landmarker.detectForVideo(v, now);
      st.frameCount++;
      if (res && res.faceBlendshapes && res.faceBlendshapes.length) {
        st._bs = bsToMap(res.faceBlendshapes[0].categories);
        st._faceLost = false;
      } else {
        // ★ v1.2.12b: 丢脸不清空 — 保留上次值 (VTS 语义: 脸出画参数冻结),
        //   避免"检测帧(30fps)与渲染帧(60fps)竞态"导致的参数闪跳
        st._faceLost = true;
      }
      if (res && res.facialTransformationMatrixes && res.facialTransformationMatrixes.length) {
        st._euler = eulerFromMatrix(res.facialTransformationMatrixes[0].data);
        // 中性姿态采集: 前 N 帧累积均值
        if (st._euler && !st.neutralReady) {
          st._neutralBuf.push(st._euler);
          if (st._neutralBuf.length >= CFG.neutralFrames) {
            var sy = 0, sp = 0, sr = 0, k;
            for (k = 0; k < st._neutralBuf.length; k++) {
              sy += st._neutralBuf[k].yaw; sp += st._neutralBuf[k].pitch; sr += st._neutralBuf[k].roll;
            }
            var n = st._neutralBuf.length;
            st._neutral = { yaw: sy / n, pitch: sp / n, roll: sr / n };
            st.neutralReady = true;
            log('neutral captured: ' + JSON.stringify(st._neutral));
          }
        }
      }
      // ★ v1.2.13: 隐私预览 — 画关键点网格 (不放用户画面)
      st._landmarks = (res && res.faceLandmarks && res.faceLandmarks[0]) || null;
      try { drawFacePreview(st._landmarks); } catch (eD) {}
      st.last = { bs: st._bs, euler: st._euler, frame: st.frameCount };
    } catch (e) {
      log('detect error: ' + (e && e.message || e));
    }
  }

  // ===== video 元素 (★ v1.2.13: 隐私改造 — 视频帧只喂 MediaPipe, 不显示;
  //  display:none 在部分内核会停帧, 用 opacity:0 + 1px 保流) =====
  function ensureVideo() {
    if (st._video) return st._video;
    var v = document.createElement('video');
    v.id = 'fcVideo';
    v.setAttribute('playsinline', '');
    v.setAttribute('autoplay', '');
    v.muted = true;
    v.style.cssText = 'position:fixed;left:0;top:0;width:2px;height:2px;opacity:0;' +
                      'pointer-events:none;z-index:-1;';
    document.body.appendChild(v);
    st._video = v;
    return v;
  }

  // ===== ★ v1.2.13: 隐私预览 — 不放用户画面, 画识别关键点连线 =====
  // FaceLandmarker.FACE_LANDMARKS_CONTOURS = 眉/眼/虹膜/唇/脸轮廓组合
  // (~130 条线, TESSELATION 2000+ 条太密太费). 线条是抽象网格, 不透出人脸.
  function ensureCanvas() {
    if (st._canvas) return st._canvas;
    var box = document.getElementById('fcPreview');
    if (!box) return null;
    var c = document.createElement('canvas');
    c.id = 'fcCanvas';
    c.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;' +
                      'background:#101418;';
    // 在状态条之前插入 (状态条要压在 canvas 上面)
    var stt = document.getElementById('fcStatus');
    box.insertBefore(c, stt);
    st._canvas = c;
    st._ctx = c.getContext('2d');
    return c;
  }

  /** 把 landmarks (归一化 478 点) 画成识别网格. */
  function drawFacePreview(landmarks) {
    var c = st._canvas, ctx = st._ctx;
    if (!c || !ctx) return;
    var w = c.width = c.clientWidth || 118;
    var h = c.height = c.clientHeight || 157;
    ctx.clearRect(0, 0, w, h);
    if (!landmarks || !landmarks.length) {
      // 无人脸: 中央提示
      ctx.fillStyle = '#5a6a75';
      ctx.font = '10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('未检测到人脸', w / 2, h / 2);
      return;
    }
    var conn = st._contours;
    if (!conn) {
      try { conn = st._contours = global.MPVision.FaceLandmarker.FACE_LANDMARKS_CONTOURS; }
      catch (e) { conn = st._contours = []; }
    }
    ctx.strokeStyle = 'rgba(64, 224, 200, 0.85)';
    ctx.lineWidth = 1;
    // ★ 照镜子语义: x 做镜像 (1-x), 头向左偏时网格也向左偏, 与直觉一致
    ctx.beginPath();
    for (var i = 0; i < conn.length; i++) {
      var a = landmarks[conn[i].start], b = landmarks[conn[i].end];
      if (!a || !b) continue;
      ctx.moveTo((1 - a.x) * w, a.y * h);
      ctx.lineTo((1 - b.x) * w, b.y * h);
    }
    ctx.stroke();
    // 头姿态微可视化: 鼻尖点画大点 (转头的直观锚)
    var nose = landmarks[1];
    if (nose) {
      ctx.fillStyle = '#ffd166';
      ctx.beginPath();
      ctx.arc((1 - nose.x) * w, nose.y * h, 2.5, 0, 6.284);
      ctx.fill();
    }
  }

  // ===== 模型挂载: AOP internalModel.updateFocus =====
  st.attach = function (model) {
    try {
      if (!model || !model.internalModel) return false;
      var im = model.internalModel, cm = im.coreModel;
      // 换模型: 拆旧 AOP
      if (st._aop && st._aop.im === model.internalModel) return true;   // 同模型幂等
      if (st._aop && st._aop.orig) {
        try { st._aop.im.updateFocus = st._aop.orig; } catch (e0) {}
      }
      st._cm = cm;
      st._idx = buildIndex(cm);
      st._sm = {};
      st._neutral = null;
      st._neutralBuf = [];
      st.neutralReady = false;
      var orig = typeof im.updateFocus === 'function' ? im.updateFocus.bind(im) : null;
      im.updateFocus = function () {
        var r = orig ? orig.apply(this, arguments) : undefined;
        try { if (st.state === 'running') applyToCore(); } catch (e) {}
        return r;
      };
      st._aop = { im: im, orig: orig };
      var n = Object.keys(st._idx).length;
      log('attached, params mapped: ' + n);
      return n > 0;
    } catch (e) {
      log('attach fail: ' + (e && e.message || e));
      return false;
    }
  };

  // ===== 启动 =====
  async function start() {
    if (st.state === 'running' || st.state === 'starting') return;
    if (!st.supported) {
      setState('error', '此环境不支持摄像头面捕');
      return;
    }
    setState('starting');
    try {
      // ① FaceLandmarker (GPU 失败降级 CPU)
      if (!st._landmarker) {
        var F = global.MPVision;
        var fileset = await F.FilesetResolver.forVisionTasks(CFG.wasmBase);
        var mk = function (delegate) {
          return F.FaceLandmarker.createFromOptions(fileset, {
            baseOptions: { modelAssetPath: CFG.modelPath, delegate: delegate },
            runningMode: 'VIDEO',
            numFaces: 1,
            outputFaceBlendshapes: true,
            outputFacialTransformationMatrixes: true
          });
        };
        try { st._landmarker = await mk('GPU'); }
        catch (eGpu) { log('GPU delegate fail, fallback CPU: ' + (eGpu && eGpu.message || eGpu)); st._landmarker = await mk('CPU'); }
      }
      // ② 摄像头
      var v = ensureVideo();
      if (!st._stream) {
        st._stream = await global.navigator.mediaDevices.getUserMedia({
          audio: false,
          video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } }
        });
      }
      v.srcObject = st._stream;
      await new Promise(function (res) {
        if (v.readyState >= 2) return res();
        v.onloadeddata = res;
        setTimeout(res, 3000);   // 兜底
      });
      try { await v.play(); } catch (eP) {}
      // ★ v1.2.13: 预览窗 canvas (识别线条视图)
      ensureCanvas();
      // ③ 循环
      st._lastTs = 0;
      setState('running');
      cancelAnimationFrame(st._raf);
      st._raf = requestAnimationFrame(loop);
      log('started');
    } catch (e) {
      var msg = e && e.message || String(e);
      if (/Permission|NotAllowed/.test(msg)) msg = '摄像头授权被拒绝';
      else if (/NotFound|DevicesNotFound/.test(msg)) msg = '未找到可用摄像头';
      log('start fail: ' + msg);
      cleanup();
      setState('error', msg);
    }
  }

  // ===== 停止 (EMA 状态保留则重启更平滑, 但快照不含面捕值 → 停用即自然恢复) =====
  // ★ v1.2.12b 拆库修正: 这个 fork 的 coreModel.loadParameters 全库无人调用
  //   (只有 saveParameters, 快照恢复机制不运行) → 面捕参数写在渲染层后会一直
  //   驻留, 停用时必须主动复位回默认值 (v1.2.10 resetExprParams 同款手法).
  function resetCaptureParams() {
    var cm = st._cm, idx = st._idx;
    if (!cm || !idx) return 0;
    var n = 0;
    for (var pid in idx) {
      if (!Object.prototype.hasOwnProperty.call(idx, pid)) continue;
      try {
        var i = idx[pid];
        cm.setParameterValueByIndex(i, cm.getParameterDefaultValue(i));
        n++;
      } catch (e) {}
    }
    return n;
  }
  function cleanup() {
    try { cancelAnimationFrame(st._raf); } catch (e) {}
    st._raf = 0;
    try { if (st._stream) { var ts = st._stream.getTracks(); for (var i = 0; i < ts.length; i++) ts[i].stop(); } } catch (e2) {}
    st._stream = null;
    try { if (st._video) st._video.srcObject = null; } catch (e3) {}
    st._bs = {};
    st._euler = null;
    st._sm = {};
    st._neutral = null;
    st._neutralBuf = [];
    st.neutralReady = false;
    st.out = null;
    st._landmarks = null;
    try { if (st._ctx) st._ctx.clearRect(0, 0, st._canvas.width, st._canvas.height); } catch (e5) {}
    st._faceLost = false;
    // 复位面捕写过的参数 (渲染层残留 → 默认; 无快照恢复机制, 必须显式做)
    try { var nrs = resetCaptureParams(); log('reset params: ' + nrs); } catch (e4) {}
    // landmarker 保留 (重开免 wasm/模型重复加载); video 元素保留
  }
  st.stop = function () {
    if (st.state === 'idle') return;
    cleanup();
    setState('idle');
    log('stopped');
  };
  st.toggle = function () {
    if (st.state === 'running') st.stop();
    else start();
    return st.state;
  };

  // ===== 状态查询 (诊断/冒烟) =====
  st.getStatus = function () {
    return JSON.stringify({
      state: st.state,
      error: st.error,
      supported: st.supported,
      attached: !!st._aop,
      paramCount: st._idx ? Object.keys(st._idx).length : 0,
      frames: st.frameCount,
      neutralReady: st.neutralReady,
      hasBS: Object.keys(st._bs).length > 0,
      out: st.out,
      mpVision: !!(global.MPVision && global.MPVision.FaceLandmarker)
    });
  };

  global.FaceCapture = st;
})(window);
