/* =====================================================================
 * vrm.js — VRM 查看器引擎 (3D-1)
 * 依赖: js/vrm_bundle.js → window.VRM3D_PKG.VRM3D
 *   { THREE, VRMLoaderPlugin, VRMUtils, VRMAnimationLoaderPlugin,
 *     VRMAnimationMixer, ... }
 * 功能:
 *   - three.js 场景 (灯光/地面影/透明背景)
 *   - VRM 模型加载 (rotateVRM0 + combineSkeletons 优化 + SpringBone)
 *   - VRMA 动画点播 (VRMAnimationMixer 桥接 humanoid/expression)
 *   - 表情 chips (expressionManager set/toggle)
 *   - 触屏轨道控制 (单指旋转 / 双指缩放 / 滚轮)
 *   - FPS 30/60 档位 + 页面隐藏暂停
 *   - library.json 装载模型/动画清单 (Java 导入后由原生侧重建)
 * ===================================================================== */
(function () {
  'use strict';
  // ★ 挂载路径双兼容: entry 主体挂 window.VRM3D; esbuild global-name 的
  //   VRM3D_PKG 对无导出 entry 返回空对象, 仅作旧路径兜底.
  var PKG = (window.VRM3D && window.VRM3D.THREE) ? window.VRM3D
          : (window.VRM3D_PKG && window.VRM3D_PKG.VRM3D);
  if (!PKG || !PKG.THREE || !PKG.VRMLoaderPlugin) {
    maskFail('3D 引擎包 (vrm_bundle.js) 加载失败');
    return;
  }
  var THREE = PKG.THREE;
  var GLTFLoader = PKG.GLTFLoader;
  // ★ 3D-1.5: 面捕 (vrm_face.js, 可选 — 缺文件时全部功能静默跳过)
  var FaceCap = window.VrmFace || null;   // three 0.166: GLTFLoader 在 examples/jsm, 由 entry 顶层导出

  /* ---------------- 状态 ---------------- */
  var st = {
    vrm: null,            // 当前 VRM 实例
    plain: null,          // 当前普通 glTF 模型 { scene, height } (无 VRM 扩展的 glb/gltf/fbx)
    mixer: null,          // VRMAnimationMixer
    action: null,         // 当前 AnimationAction
    anims: {},            // name -> VRMAnimation (已加载)
    exprOn: {},           // 表情名 -> bool
    fps60: true,
    paused: false,
    lastKind: 'none',     // ★ v1.1.3: 最近一次载入的分支 (vrm/plain-gltf/fbx)
    library: { models: [], animations: [] }
  };

  var canvas = document.getElementById('gl');
  var renderer, scene, camera;
  var shadowMesh;
  var lastFrame = 0;

  /* ---------------- 轨道相机 ---------------- */
  var ORBIT_HOME = null;   // 模型加载后按身高计算
  var orbit = { theta: 0, phi: 1.35, radius: 2.6, target: null };
  function applyCamera() {
    if (!orbit.target) return;
    var sp = Math.sin(orbit.phi);
    camera.position.set(
      orbit.target.x + orbit.radius * sp * Math.sin(orbit.theta),
      orbit.target.y + orbit.radius * Math.cos(orbit.phi),
      orbit.target.z + orbit.radius * sp * Math.cos(orbit.theta));
    camera.lookAt(orbit.target);
  }
  function resetOrbit() {
    if (!ORBIT_HOME) return;
    orbit.theta = ORBIT_HOME.theta; orbit.phi = ORBIT_HOME.phi;
    orbit.radius = ORBIT_HOME.radius; orbit.target.copy(ORBIT_HOME.target);
    applyCamera();
  }

  // --- 触摸手势: 单指旋转, 双指捏合缩放 ---
  var touches = {};
  var pinchDist0 = 0, radiusAtPinch = 0;
  canvas.addEventListener('touchstart', function (e) {
    var ts = e.changedTouches;
    for (var i = 0; i < ts.length; i++) touches[ts[i].identifier] = { x: ts[i].clientX, y: ts[i].clientY };
    var ids = Object.keys(touches);
    if (ids.length === 2) {
      var a = touches[ids[0]], b = touches[ids[1]];
      pinchDist0 = Math.hypot(a.x - b.x, a.y - b.y);
      radiusAtPinch = orbit.radius;
    }
  }, { passive: true });
  canvas.addEventListener('touchmove', function (e) {
    e.preventDefault();
    var ts = e.changedTouches, ids = Object.keys(touches);
    for (var i = 0; i < ts.length; i++) {
      var t = touches[ts[i].identifier];
      if (!t) continue;
      var dx = ts[i].clientX - t.x, dy = ts[i].clientY - t.y;
      t.x = ts[i].clientX; t.y = ts[i].clientY;
      if (ids.length === 1) {
        orbit.theta -= dx * 0.0075;
        orbit.phi = clamp(orbit.phi - dy * 0.006, 0.12, Math.PI * 0.96);
      }
    }
    if (ids.length === 2) {
      var A = touches[ids[0]], B = touches[ids[1]];
      var d = Math.hypot(A.x - B.x, A.y - B.y);
      if (pinchDist0 > 0) orbit.radius = clamp(radiusAtPinch * pinchDist0 / Math.max(d, 24), 0.55, 14);
    }
    applyCamera();
  }, { passive: false });
  canvas.addEventListener('touchend', function (e) {
    var ts = e.changedTouches;
    for (var i = 0; i < ts.length; i++) delete touches[ts[i].identifier];
    pinchDist0 = 0;
  });
  // --- 桌面: 滚轮缩放 + 拖拽旋转 (调试) ---
  canvas.addEventListener('wheel', function (e) {
    e.preventDefault();
    orbit.radius = clamp(orbit.radius * (1 + Math.sign(e.deltaY) * 0.09), 0.55, 14);
    applyCamera();
  }, { passive: false });
  var dragOn = false, dragX = 0, dragY = 0;
  canvas.addEventListener('mousedown', function (e) { dragOn = true; dragX = e.clientX; dragY = e.clientY; });
  window.addEventListener('mousemove', function (e) {
    if (!dragOn) return;
    orbit.theta -= (e.clientX - dragX) * 0.0075;
    orbit.phi = clamp(orbit.phi - (e.clientY - dragY) * 0.006, 0.12, Math.PI * 0.96);
    dragX = e.clientX; dragY = e.clientY;
    applyCamera();
  });
  window.addEventListener('mouseup', function () { dragOn = false; });

  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }

  /* ---------------- 场景 ---------------- */
  function initScene() {
    renderer = new THREE.WebGLRenderer({
      canvas: canvas, antialias: true, alpha: true,
      preserveDrawingBuffer: true          // 备用: 截图/调试导出
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(window.innerWidth, window.innerHeight, false);

    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(30, window.innerWidth / window.innerHeight, 0.08, 32);

    // 灯光 (r155+ 物理光照单位) ★ 修正过曝: 原约 2π 总强度把白色 MToon
    //   推到纯白 clip; MToon 期望无 tone mapping + 适度灯强 →
    //   主灯 0.95π + 环境 0.35π + 极弱轮廓 0.12π ≈ 1.4π
    scene.add(new THREE.AmbientLight(0xffffff, 0.35 * Math.PI));
    var dir = new THREE.DirectionalLight(0xffffff, 0.95 * Math.PI);
    dir.position.set(0.8, 1.6, 1.0);
    scene.add(dir);
    var rim = new THREE.DirectionalLight(0xdde6ff, 0.12 * Math.PI);
    rim.position.set(-1.2, 0.9, -0.8);
    scene.add(rim);

    // 柔和椭圆地面影 (径向渐变贴图, 不引阴影管线, 移动端零开销)
    var c2 = document.createElement('canvas');
    c2.width = c2.height = 128;
    var g = c2.getContext('2d');
    var grad = g.createRadialGradient(64, 64, 4, 64, 64, 62);
    grad.addColorStop(0, 'rgba(70,85,110,0.34)');
    grad.addColorStop(0.62, 'rgba(70,85,110,0.13)');
    grad.addColorStop(1, 'rgba(70,85,110,0)');
    g.fillStyle = grad;
    g.fillRect(0, 0, 128, 128);
    var shTex = new THREE.CanvasTexture(c2);
    shadowMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(1, 1),
      new THREE.MeshBasicMaterial({ map: shTex, transparent: true, depthWrite: false }));
    shadowMesh.rotation.x = -Math.PI / 2;
    scene.add(shadowMesh);

    window.addEventListener('resize', onResize);
    onResize();
    applyCamera();
  }
  function onResize() {
    if (!renderer) return;
    renderer.setSize(window.innerWidth, window.innerHeight, false);
    camera.aspect = window.innerWidth / Math.max(1, window.innerHeight);
    camera.updateProjectionMatrix();
  }

  /* ---------------- 渲染循环 ---------------- */
  function tick() {
    requestAnimationFrame(tick);
    if (st.paused) { lastFrame = 0; return; }
    var now = performance.now();
    if (!st.fps60) {                       // 30FPS 档: 33.3ms 节流
      if (lastFrame && now - lastFrame < 30) return;
    }
    var dt = lastFrame ? Math.min((now - lastFrame) / 1000, 0.1) : 0.016;
    lastFrame = now;
    try {
      if (st.mixer) st.mixer.update(dt);
      if (FaceCap && FaceCap.state === 'running') FaceCap.applyFrame();
      if (st.vrm) st.vrm.update(dt);       // humanoid/springbone/lookat/expression
      renderer.render(scene, camera);
    } catch (e) { /* 单帧异常不炸循环 */ }
  }
  document.addEventListener('visibilitychange', function () {
    st.paused = document.hidden;          // 恢复时 tick 内 lastFrame=0 防大步长
  });

  /* ---------------- VRM 模型加载 ---------------- */
  function loadVRM(rel) {
    maskShow('正在加载模型…', rel);
    var loader = new GLTFLoader();
    loader.register(function (parser) { return new PKG.VRMLoaderPlugin(parser); });
    return loader.loadAsync(rel).then(function (gltf) {
      var vrm = gltf.userData.vrm;
      if (!vrm) return loadPlainGltf(gltf, rel);   // ★ glb/gltf 无 VRM 扩展: 普通渲染
      if (st.plain) {                      // 卸旧普通 glTF
        stopAnim(true); st.mixer = null;
        scene.remove(st.plain.scene);
        st.plain = null;
      }
      if (st.vrm) {                        // 卸旧模型
        stopAnim(true);
        st.mixer = null;                   // mixer 绑旧 scene, 一并弃
        scene.remove(st.vrm.scene);
        if (PKG.VRMUtils.deepDispose) PKG.VRMUtils.deepDispose(st.vrm.scene);
      }
      st.vrm = vrm;
      st.lastKind = 'vrm';
      st.exprOn = {};
      // 骨骼合并优化 (3.0+, 老版本不存在则跳过)
      if (PKG.VRMUtils.combineSkeletons) {
        try { PKG.VRMUtils.combineSkeletons(gltf.scene); } catch (e0) {}
      }
      if (PKG.VRMUtils.rotateVRM0) PKG.VRMUtils.rotateVRM0(vrm);  // VRM0 面向校正
      scene.add(vrm.scene);

      // 依身高取景: hips 位置近似脚底, 头顶≈身高
      var hips = vrm.humanoid && vrm.humanoid.getNormalizedBoneNode('hips');
      var head = vrm.humanoid && vrm.humanoid.getNormalizedBoneNode('head');
      var hHips = hips ? Math.max(hips.getWorldPosition(new THREE.Vector3()).y, 0.02) : 0.9;
      var hHead = head ? head.getWorldPosition(new THREE.Vector3()).y : 1.5;
      var footY = Math.max(hHips * 0.45, 0.03);
      vrm.scene.position.y -= footY;       // 踩地
      var height = Math.max(hHead - footY, 0.4);
      shadowMesh.scale.set(height * 0.9, height * 0.36, 1);
      shadowMesh.position.y = 0.001;

      orbit.target = new THREE.Vector3(0, height * 0.55, 0);
      orbit.radius = height * 2.45;
      orbit.theta = 0; orbit.phi = 1.42;
      ORBIT_HOME = { theta: 0, phi: 1.42, radius: height * 2.45, target: orbit.target.clone() };
      applyCamera();
      buildExprChips();
      if (FaceCap) { try { FaceCap.attach(vrm); } catch (eFc) {} }
      buildAnimBar();          // 从 plain 切回时重建 VRMA chips
      maskHide();
      toast('模型已加载: ' + shortName(rel));
    }).catch(function (e1) {
      maskFail('模型加载失败: ' + (e1 && e1.message ? e1.message : e1));
      throw e1;
    });
  }

  // ★ v1.1.3: 通用取景归一 — 把任意来源模型 (glTF/FBX/...) 摆到"踩地 + 合适高度".
  //   上阈值 20: 超过就认定是 cm 制/原始导出单位 (Fox 79m, Lantern 25m, 斯坦福兔
  //   这类"大数"模型), 按 1.7/h 缩到人形高度. 人形模型 (1.4~2.0m) 原样保留.
  //   下阈值 0.4: 微型模型 (如 Avocado 0.1m) 放大到可看尺寸; 避免"加载成功但
  //   整个画面只有一粒芝麻"的体验.
  //   返回 { obj, h } — h 为归一后的可视高度.
  function frameModel(obj) {
    obj.updateMatrixWorld(true);
    var bbox = new THREE.Box3().setFromObject(obj);
    var h = Math.max(bbox.max.y - bbox.min.y, 0.1);
    // 先归一尺寸, 再踩地 (缩放会改 bbox, 顺序不能反)
    if (h > 20) { obj.scale.multiplyScalar(1.7 / h); obj.updateMatrixWorld(true); h = 1.7; }
    else if (h < 0.4) { obj.scale.multiplyScalar(1.0 / h); obj.updateMatrixWorld(true); h = 1.0; }
    bbox = new THREE.Box3().setFromObject(obj);
    obj.position.y -= bbox.min.y;                 // 踩地
    return h;
  }

  // ★ 普通 glTF/GLB 渲染 (无 VRM 扩展): 踩地取景照常, 无表情/无 SpringBone;
  //   自带动画的话交给 FBX/GLTF 通用动画条目 (见 loadEmbeddedClips)
  function loadPlainGltf(gltf, rel) {
    if (st.vrm) {
      stopAnim(true); st.mixer = null;
      scene.remove(st.vrm.scene || st.vrm);
      if (PKG.VRMUtils.deepDispose) try { PKG.VRMUtils.deepDispose(st.vrm.scene || st.vrm); } catch (e0) {}
    }
    st.vrm = null;
    st.exprOn = {};
    var obj = gltf.scene || gltf.scenes[0];
    var h = frameModel(obj);                      // ★ v1.1.3: 归一 (大尺寸模型缩放)
    scene.add(obj);
    st.plain = { scene: obj, height: h };
    st.lastKind = 'plain-gltf';
    shadowMesh.scale.set(h * 0.9, h * 0.36, 1);
    shadowMesh.position.y = 0.001;
    orbit.target = new THREE.Vector3(0, h * 0.55, 0);
    orbit.radius = h * 2.45;
    orbit.theta = 0; orbit.phi = 1.42;
    ORBIT_HOME = { theta: 0, phi: 1.42, radius: h * 2.45, target: orbit.target.clone() };
    applyCamera();
    document.getElementById('exprBar').classList.remove('show');
    loadEmbeddedClips(gltf, obj);                 // 自带动画点播 (fbx/gltf 通用)
    if (FaceCap) { try { FaceCap.attach(null); } catch (e1) {} }   // 解除旧挂载
    maskHide();
    toast('已加载 glTF (无 VRM 扩展, 表情/物理不可用)');
    return Promise.resolve();
  }
  // glTF/FBX 内嵌动画 → 通用 chips (与 VRMA 点播同槽位)
  function loadEmbeddedClips(gltf, root) {
    if (!gltf.animations || !gltf.animations.length) return;
    if (!st.mixer) st.mixer = new THREE.AnimationMixer(root);
    else st.mixer = new THREE.AnimationMixer(root);   // root 换了重建
    st.embedded = gltf.animations;
    var bar = document.getElementById('animBar');
    bar.innerHTML = '';
    bar.classList.add('show');
    gltf.animations.forEach(function (clip, i) {
      var b = document.createElement('div');
      b.className = 'chip';
      var nm = clip.name || ('动画' + (i + 1));
      b.textContent = '▶ ' + nm;
      b.dataset.name = nm;
      b.onclick = function () {
        if (b.classList.contains('on')) { stopAnim(); return; }
        stopAnim(true);
        st.action = st.mixer.clipAction(gltf.animations[i]);
        st.action.reset().play();
        setChipOn('#animBar', nm, true);
        toast('▶ ' + nm);
      };
      bar.appendChild(b);
    });
  }

  /* ---------------- VRMA 动画 ---------------- */
  function loadVRMA(rel) {
    var loader = new GLTFLoader();
    loader.register(function (parser) { return new PKG.VRMAnimationLoaderPlugin(parser); });
    return loader.loadAsync(rel).then(function (gltf) {
      var anim = gltf.userData.vrmAnimations && gltf.userData.vrmAnimations[0];
      if (!anim) throw new Error('无效的 VRMA 动画文件');
      if ('lookAtTargetParent' in anim) { try { anim.lookAtTargetParent = st.vrm.scene; } catch (e2) {} }
      return anim;
    });
  }
  function playAnim(name) {
    var rel = animRelByName(name);
    if (!rel) return;
    var go = function (anim) {
      if (!st.vrm) { toast('请先加载模型'); return; }
      stopAnim(true);
      // ★ three-vrm-animation 3.x: 无 VRMAnimationMixer, 用 createVRMAnimationClip
      //   转 AnimationClip + 原生 AnimationMixer (root = vrm.scene)
      if (!PKG.createVRMAnimationClip) { toast('bundle 缺少动画桥接'); return; }
      var clip = PKG.createVRMAnimationClip(anim, st.vrm);
      if (!st.mixer) st.mixer = new THREE.AnimationMixer(st.vrm.scene);
      st.action = st.mixer.clipAction(clip);
      st.action.reset().play();
      setChipOn('#animBar', name, true);
      toast('▶ ' + name);
    };
    if (st.anims[name]) { go(st.anims[name]); return; }
    toast('加载动画…');
    loadVRMA(rel).then(function (anim) {
      st.anims[name] = anim;
      go(anim);
    }).catch(function (e3) { toast('动画失败: ' + (e3 && e3.message ? e3.message : e3)); });
  }
  function stopAnim(silent) {
    if (st.action) { try { st.action.stop(); } catch (e4) {} st.action = null; }
    setChipOn('#animBar', null, false);
    if (!silent) toast('已停止动画');
  }
  function animRelByName(name) {
    var L = st.library.animations;
    for (var i = 0; i < L.length; i++) if (L[i].name === name) return L[i].file;
    return null;
  }

  /* ---------------- 表情 ---------------- */
  function buildExprChips() {
    var bar = document.getElementById('exprBar');
    bar.innerHTML = '';
    var names = [];
    try {
      var em = st.vrm.expressionManager;
      if (em && em.expressions) {
        for (var i = 0; i < em.expressions.length; i++) {
          var en = em.expressions[i].expressionName;
          if (en && names.indexOf(en) < 0) names.push(en);
        }
      }
    } catch (e5) {}
    bar.classList.toggle('show', names.length > 0);
    if (!names.length) return;
    names.forEach(function (n) {
      var b = document.createElement('div');
      b.className = 'chip';
      b.textContent = n;
      b.dataset.name = n;
      b.onclick = function () {
        var on = !st.exprOn[n];
        st.exprOn[n] = on;
        try { st.vrm.expressionManager.setValue(n, on ? 1.0 : 0.0); } catch (e6) {}
        b.classList.toggle('on', on);
      };
      bar.appendChild(b);
    });
  }
  function clearExprChips() {
    var bar = document.getElementById('exprBar');
    var kids = bar.children;
    for (var i = 0; i < kids.length; i++) {
      var n = kids[i].dataset.name;
      if (st.exprOn[n]) {
        try { st.vrm.expressionManager.setValue(n, 0.0); } catch (e7) {}
      }
    }
    st.exprOn = {};
  }
  function setChipOn(barSel, name, on) {
    var bar = document.querySelector(barSel);
    if (!bar) return;
    var kids = bar.children;
    for (var i = 0; i < kids.length; i++) {
      if (kids[i].dataset.name === name) kids[i].classList.toggle('on', on);
      else kids[i].classList.remove('on');
    }
  }

  /* ---------------- library.json ---------------- */
  function loadLibrary() {
    // ★ 双路径: WebView 虚拟域清单由 Java 生成于 /lib/library.json (含导入项);
    //   本地 http 调试无 Java, 用同目录 library.json 兜底
    var candidates = ['/lib/library.json', 'library.json'];   // 绝对虚拟路径优先
    var i = 0;
    function tryNext() {
      if (i >= candidates.length) {
        st.library.models = []; st.library.animations = [];
        return Promise.resolve();
      }
      var url = candidates[i++] + '?ts=' + Date.now();
      return fetch(url)
        .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .then(function (j) {
          st.library.models = j.models || [];
          st.library.animations = j.animations || [];
        })
        .catch(tryNext);
    }
    return tryNext();
  }
  function shortName(rel) {
    var s = String(rel).split('/');
    return decodeURIComponent(s[s.length - 1]).replace(/\.(vrm|vrma)$/i, '');
  }
  function buildModelSelect(prefer) {
    var sel = document.getElementById('selModel');
    sel.innerHTML = '';
    var list = st.library.models.slice();
    // ★ v1.2.14 archive 模式: URL 指定的模型可能不在 library.json 里
    //   (压缩包查看器直看场景, 模型在解压临时域 /arc/ 下), 直通成临时条目
    if (prefer && !list.some(function (m) { return m.file === prefer; })) {
      list = [{ file: prefer, name: shortName(prefer) + ' (压缩包)' }].concat(list);
      st._archiveModel = prefer;
    }
    if (!list.length) {
      var o = document.createElement('option');
      o.value = ''; o.textContent = '(无可用模型)';
      sel.appendChild(o);
      return null;
    }
    list.forEach(function (m) {
      var o = document.createElement('option');
      o.value = m.file;
      o.textContent = m.name || shortName(m.file);
      sel.appendChild(o);
    });
    var pick = prefer && list.some(function (m) { return m.file === prefer; }) ? prefer : list[0].file;
    sel.value = pick;
    return pick;
  }
  function buildAnimBar() {
    var bar = document.getElementById('animBar');
    bar.innerHTML = '';
    var list = st.library.animations;
    bar.classList.toggle('show', list.length > 0);
    if (!list.length) return;
    list.forEach(function (a) {
      var b = document.createElement('div');
      b.className = 'chip';
      b.textContent = '▶ ' + (a.name || shortName(a.file));
      b.dataset.name = a.name || shortName(a.file);
      b.onclick = function () {
        if (b.classList.contains('on')) { stopAnim(); return; }  // 再点停止
        playAnim(b.dataset.name);
      };
      bar.appendChild(b);
    });
  }

  /* ---------------- UI 杂项 ---------------- */
  var maskEl = document.getElementById('mask');
  var maskText = document.getElementById('maskText');
  var maskSub = document.getElementById('maskSub');
  var maskSpin = document.getElementById('maskSpin');
  function maskShow(txt, sub) {
    maskText.textContent = txt;
    maskSub.textContent = sub || '';
    maskSpin.style.display = 'block';
    maskEl.classList.remove('hide');
  }
  function maskHide() { maskEl.classList.add('hide'); }
  function maskFail(txt) {
    maskText.textContent = txt;
    maskSub.textContent = '请检查资源包是否完整';
    maskSpin.style.display = 'none';
    maskEl.classList.remove('hide');
  }
  var toastEl = document.getElementById('toast'), toastTimer = 0;
  function toast(t) {
    toastEl.textContent = t;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove('show'); }, 1800);
  }

  function loadModelAuto(rel) {
    var low = String(rel).toLowerCase();
    if (/\.fbx(\?|$)/.test(low)) return loadFBX(rel);
    return loadVRM(rel);
  }
  // ★ FBX (three examples FBXLoader, fflate 已随 bundle 打包):
  //   渲染 + 内嵌动画点播; 骨骼/表情无 VRM 标准, 面捕表情不可用
  function loadFBX(rel) {
    if (!PKG.FBXLoader) { maskFail('bundle 未含 FBXLoader'); return; }
    maskShow('正在加载 FBX 模型…', rel);
    return new PKG.FBXLoader().loadAsync(rel).then(function (obj) {
      // ★ v1.1.3: 与 plain-gltf 共用取景归一 (cm 制 FBX 自动缩到人形高度)
      var h = frameModel(obj);
      if (st.plain) { stopAnim(true); st.mixer = null; scene.remove(st.plain.scene); }
      if (st.vrm) { stopAnim(true); st.mixer = null; scene.remove(st.vrm.scene);
        if (PKG.VRMUtils.deepDispose) try { PKG.VRMUtils.deepDispose(st.vrm.scene); } catch (e2) {} }
      st.vrm = null; st.plain = { scene: obj, height: h };
      st.lastKind = 'fbx';
      scene.add(obj);
      shadowMesh.scale.set(h * 0.9, h * 0.36, 1);
      shadowMesh.position.y = 0.001;
      orbit.target = new THREE.Vector3(0, h * 0.55, 0);
      orbit.radius = h * 2.45;
      orbit.theta = 0; orbit.phi = 1.42;
      ORBIT_HOME = { theta: 0, phi: 1.42, radius: h * 2.45, target: orbit.target.clone() };
      applyCamera();
      document.getElementById('exprBar').classList.remove('show');
      loadEmbeddedClips(obj, obj);   // FBX 内嵌动画 (animations 由 loader 填充)
      if (FaceCap) { try { FaceCap.attach(null); } catch (e3) {} }
      maskHide();
      toast('已加载 FBX (无 VRM 表情/物理, 自带动画可点播)');
    }).catch(function (e4) {
      maskFail('FBX 加载失败: ' + (e4 && e4.message ? e4.message : e4));
      throw e4;
    });
  }

  document.getElementById('selModel').onchange = function () {
    if (this.value) loadModelAuto(this.value);
  };
  document.getElementById('btnReset').onclick = resetOrbit;
  // ★ 3D-1.5: 面捕开关 (开面捕自动停动画 — VRMA 的 expression/head 轨道会打架)
  var fcBtn = document.getElementById('btnFc');
  var fcPreview = document.getElementById('fcPreview');
  var fcStatus = document.getElementById('fcStatus');
  if (fcBtn) {
    fcBtn.onclick = function () {
      if (!FaceCap) { toast('面捕模块未加载 (vrm_face.js)'); return; }
      if (!FaceCap.supported) { toast('面捕不可用: ' + (FaceCap.error || '环境不支持')); return; }
      if (FaceCap.state === 'running') {
        FaceCap.stop();
      } else if (FaceCap.state === 'error') {
        FaceCap.start();          // 错误态允许重试
      } else {
        if (st.action) { stopAnim(); toast('已停动画, 面捕接管表情'); }
        toast('启动面捕…');
        FaceCap.start();
      }
    };
  }
  if (FaceCap) {
    FaceCap.on(function (ev) {
      if (ev.type === 'state') {
        fcSyncUI();
        if (ev.type === 'state' && ev.state === 'error') toast('面捕失败: ' + ev.error);
      }
    });
    setInterval(fcSyncUI, 500);
  }
  function fcSyncUI() {
    if (!fcBtn || !FaceCap) return;
    var running = FaceCap.state === 'running';
    fcBtn.classList.toggle('on', running);
    fcPreview.classList.toggle('show', running);
    if (fcStatus) {
      var txt = { idle: '待机', starting: '启动中…', running: '面捕中 ' + FaceCap.frameCount + '帧' }[FaceCap.state] || FaceCap.state;
      if (FaceCap.state === 'error') txt = '错误: ' + FaceCap.error;
      else if (running && FaceCap.neutralReady) txt += ' · 已校零';
      else if (running && FaceCap._faceLost) txt += ' · 未检测到人脸';
      fcStatus.textContent = txt;
    }
  }
  document.getElementById('btnFps').onclick = function () {
    st.fps60 = !st.fps60;
    this.textContent = st.fps60 ? '60FPS' : '30FPS';
    toast(st.fps60 ? '已切换 60FPS' : '已切换 30FPS (省电)');
  };

  /* ---------------- 测试钩子 (headless 冒烟用) ---------------- */
  window.__vrmTest = {
    ready: function () { return !!(renderer && scene && camera); },
    hasVrm: function () { return !!st.vrm; },
    exprCount: function () {
      try {
        var em = st.vrm && st.vrm.expressionManager;
        return em && em.expressions ? em.expressions.length : 0;
      } catch (e) { return -1; }
    },
    setExpr: function (n, w) {
      try { st.vrm.expressionManager.setValue(n, w); return true; } catch (e) { return false; }
    },
    getExpr: function (n) {
      try {
        var em = st.vrm.expressionManager;
        return em ? em.getValue ? em.getValue(n) : (em.expressionMap && em.expressionMap[n] ? em.expressionMap[n].weight : -1) : -1;
      } catch (e) { return -1; }
    },
    playTestAnim: function () {
      if (!st.library.animations.length) return 'no-anims';
      playAnim(st.library.animations[0].name || shortName(st.library.animations[0].file));
      return 'ok';
    },
    animPlaying: function () { return !!(st.action && st.action.isRunning()); },
    fpsToggle: function () { document.getElementById('btnFps').onclick(); return st.fps60; },
    orbit: function () { return orbit; },
    resetView: function () { resetOrbit(); return true; },
    springBone: function () {
      return !!(st.vrm && st.vrm.springBoneManager);
    },
    libCounts: function () {
      return { models: st.library.models.length, animations: st.library.animations.length };
    },
    face: function () {
      if (!FaceCap) return null;
      return {
        state: FaceCap.state, error: FaceCap.error, supported: FaceCap.supported,
        attached: !!FaceCap._vrm,
        exprCount: FaceCap._idx ? Object.keys(FaceCap._idx).length : 0,
        hasHead: !!FaceCap._head,
        frames: FaceCap.frameCount, neutralReady: FaceCap.neutralReady,
        hasBS: Object.keys(FaceCap._bs).length > 0,
        mpVision: !!(window.MPVision && window.MPVision.FaceLandmarker)
      };
    },
    faceInject: function (bs, euler) {
      if (!FaceCap) return false;
      FaceCap.__inject(bs, euler);
      FaceCap.applyFrame();
      return true;
    },
    faceExprWeight: function (n) {
      try { return FaceCap && FaceCap._vrm ? FaceCap._vrm.expressionManager.getValue(n) : -1; }
      catch (e) { return -1; }
    },
    faceStop: function () { if (FaceCap) FaceCap.stop(); return FaceCap ? FaceCap.state : null; },
    // ★ v1.1.2: 暴露矩阵分解供三轴解耦回归用 (必须走真实分解路径 —
    //   旧 bug 就是"角度语义"理解错, 手工构造伪角度测不出来)
    faceEulerFromMatrix: function (d) {
      if (!FaceCap || !FaceCap._eulerFromMatrix) return null;
      return FaceCap._eulerFromMatrix(d);
    },
    faceHeadReset: function () {
      if (!FaceCap || !FaceCap._head) return false;
      var q = FaceCap._head.quaternion;
      return Math.abs(q.x) < 1e-6 && Math.abs(q.y) < 1e-6 && Math.abs(q.z) < 1e-6 && Math.abs(q.w - 1) < 1e-6;
    },
    // ===== ★ v1.1.3: 模型格式兼容性探针 (压力测试 / 桌宠化复用) =====
    // load: 走真实 loadModelAuto 分支 (FBX → loadFBX, 其余 → loadVRM)
    load: function (rel) { return loadModelAuto(rel); },
    // kind: 当前载入的是什么 (vrm / plain-gltf / fbx / none)
    kind: function () {
      if (st.vrm) return 'vrm';
      if (st.plain) return 'plain-gltf';
      return st.lastKind || 'none';
    },
    // 场景统计 (对 vrm / plain / fbx 三种载法统一取根节点)
    meshCount: function () {
      var root = st.vrm ? st.vrm.scene : (st.plain ? st.plain.scene : null);
      if (!root) return 0;
      var n = 0; root.traverse(function (o) { if (o.isMesh) n++; });
      return n;
    },
    triCount: function () {
      var root = st.vrm ? st.vrm.scene : (st.plain ? st.plain.scene : null);
      if (!root) return 0;
      var tris = 0;
      root.traverse(function (o) {
        if (!o.isMesh || !o.geometry) return;
        var g = o.geometry, c = g.index ? g.index.count : (g.attributes && g.attributes.position ? g.attributes.position.count : 0);
        tris += Math.floor(c / 3) * (o.isInstancedMesh ? o.count : 1);
      });
      return tris;
    },
    boneCount: function () {
      var root = st.vrm ? st.vrm.scene : (st.plain ? st.plain.scene : null);
      if (!root) return 0;
      var n = 0; root.traverse(function (o) { if (o.isBone) n++; });
      return n;
    },
    animCount: function () {
      var root = st.vrm ? st.vrm.scene : (st.plain ? st.plain.scene : null);
      return (root && root.animations) ? root.animations.length : 0;
    },
    // state: 当前模型的关键状态 (高度 / 是否 VRM / 高度来源)
    state: function () {
      if (st.vrm) {
        var b = new THREE.Box3().setFromObject(st.vrm.scene);
        return { kind: 'vrm', height: b.max.y - b.min.y, hasSpringBone: !!st.vrm.springBoneManager };
      }
      if (st.plain) return { kind: 'plain-gltf', height: st.plain.height, hasSpringBone: false };
      return { kind: 'none', height: -1, hasSpringBone: false };
    }
  };

  /* ---------------- 启动 ---------------- */
  function boot() {
    initScene();
    tick();
    // URL 直跳: ?model=models/xxx.vrm
    var q = new URLSearchParams(location.search);
    var prefer = q.get('model') ? decodeURIComponent(q.get('model')) : null;
    loadLibrary().then(function () {
      buildAnimBar();
      var pick = buildModelSelect(prefer);
      if (pick) loadModelAuto(pick);
      else maskFail('library.json 中没有可用模型');
    });
  }
  boot();
})();
