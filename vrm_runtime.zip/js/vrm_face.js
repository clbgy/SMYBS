/* =====================================================================
 * vrm_face.js — VRM 面捕 (3D-1.5: 查看器内点亮, 3D-2 桌宠复用)
 * 依赖: js/ffc/vision_iife.js (window.MPVision) + js/ffc/face_landmarker.task
 *       js/vrm_bundle.js (window.VRM3D.THREE)
 * 与 Live2D 的 ffc.js 同构: 30fps 检测 / EMA 平滑 / 丢脸冻结 / 中性姿态校零
 * / 停用复位 / 隐私线条预览 (不显示用户画面)。
 * 写入目标 (VRM 1.0):
 *   表情 preset: blink/blinkLeft/blinkRight, aa, happy, angry, sad, surprised,
 *                lookUp/lookDown/lookLeft/lookRight  (按模型实际拥有自适应)
 *   头部: vrm.humanoid.getNormalizedBoneNode('head') 四元数
 * ★ 语义: 开面捕建议停 VRMA (动画 expression/head 轨道会与面捕互相覆盖,
 *   查看器接线处已自动停动画)。
 * ===================================================================== */
(function (global) {
  'use strict';

  var CFG = {
    wasmBase: 'js/ffc/',
    modelPath: 'js/ffc/face_landmarker.task',
    detectInterval: 33,
    smooth: 0.55,
    blinkSmooth: 0.7,
    angleGain: 1.3,          // 头角度增益
    //   ★ v1.1.2: 从 2.2 降到 1.3。旧值是为了"盖过"轴串扰噪声硬拉高的,
    //     轴解耦后高增益会让小幅转头显得过冲 (18° 真实转头就顶满 28°)。
    //     1.3 下 15° 真实转头 → 20° 模型转头; 21° 才到上限, 观感自然。
    headMaxDeg: 28,          // 头骨旋转上限 (度)
    deadZone: 0.04,
    mouthGain: 1.6,
    browGain: 1.4,
    neutralFrames: 20,
    // ★ 头骨旋转符号 (MediaPipe 欧拉 → VRM 头骨轴): 方向反了改这三个 ±1
    SIGN_YAW: 1, SIGN_PITCH: 1, SIGN_ROLL: 1
  };

  var st = {
    state: 'idle', error: '',
    supported: !!(global.navigator && global.navigator.mediaDevices &&
                  global.navigator.mediaDevices.getUserMedia && global.MPVision),
    frameCount: 0, neutralReady: false, _faceLost: false,
    last: null, _listeners: [],
    _landmarker: null, _video: null, _stream: null, _raf: 0, _lastTs: 0,
    _bs: {}, _euler: null, _landmarks: null, _canvas: null, _ctx: null,
    _contours: null,
    _neutral: null, _neutralBuf: [], _sm: {},
    _vrm: null,      // 当前 VRM
    _idx: null,      // {exprName: true} 模型实际拥有的 preset 表情
    _head: null,     // normalized head node
    _e3: null        // 复用 THREE.Euler (免每帧分配)
  };

  function emit(ev) {
    ev = ev || {};
    for (var i = 0; i < st._listeners.length; i++) {
      try { st._listeners[i](ev); } catch (e) {}
    }
  }
  function setState(s, err) { st.state = s; st.error = err || ''; emit({ type: 'state', state: s, error: st.error }); }
  st.on = function (fn) { st._listeners.push(fn); };

  function log(m) {
    try { console.log('[VFC] ' + m); } catch (e) {}
  }
  function clamp(v, mn, mx) { return v < mn ? mn : (v > mx ? mx : v); }

  // ===== 表情能力探测: 模型拥有哪个 preset 才写哪个 (VRM 自适应) =====
  function buildIndex(vrm) {
    var map = {};
    try {
      var em = vrm.expressionManager;
      if (!em) return map;
      var presets = ['blink', 'blinkLeft', 'blinkRight', 'aa', 'ih', 'ou', 'ee', 'oh',
                     'happy', 'angry', 'sad', 'relaxed', 'surprised',
                     'lookUp', 'lookDown', 'lookLeft', 'lookRight'];
      for (var i = 0; i < presets.length; i++) {
        var ok = false;
        try { ok = !!(em.getExpression && em.getExpression(presets[i])); } catch (e0) {}
        if (!ok && em.expressionMap) { try { ok = !!em.expressionMap[presets[i]]; } catch (e1) {} }
        if (ok) map[presets[i]] = true;
      }
    } catch (e2) {}
    return map;
  }

  function bsToMap(categories) {
    var m = {};
    if (!categories) return m;
    for (var i = 0; i < categories.length; i++) {
      var c = categories[i];
      if (c && c.categoryName) m[c.categoryName] = c.score;
    }
    return m;
  }

  // ===== 4x4 人脸姿态矩阵 → 头角度 (v1.1.2 重写) =====
  // ★ v1.1.1 及之前的 bug: 抄了 ffc.js 的欧拉分解却丢了轴重指派, 把
  //   分解结果的 yaw 当成 three.js 的 Y 轴旋转用 → 歪头变成转头, 转头
  //   变成点头, 轴完全错位 (真机表现: "歪头它转头, 转头它不知道干嘛")。
  //   根因: mediapipe 的欧拉约定 R = Ry(yaw)·Rx(pitch)·Rz(roll) 与
  //   three.js Euler 的 Rz·Rx·Ry 顺序/轴意义都不同, 直接搬角度必错。
  // ★ v1.1.2 方案: 不用欧拉分解, 直接读旋转矩阵列向量 (脸坐标系的基
  //   在相机系中的朝向), 三轴天然解耦, 语义实测确认:
  //     歪头(roll)  → col0(脸X轴) 的 y 分量变化
  //     转头(yaw)   → col2(脸Z轴) 的 x 分量变化
  //     点头(pitch) → col1(脸Y轴) 的 z 分量变化
  //   返回 {yaw, pitch, roll} 单位: 度, 已是"人脸自然语义"(非矩阵欧拉)。
  function eulerFromMatrix(d) {
    if (!d || d.length < 11) return null;
    // 列主序展平 (行主序 4x4, 每行 4 元素): col = (d[i], d[i+4], d[i+8])
    var x0 = d[0], x1 = d[4], x2 = d[8];    // 脸 X 轴 (脸的右侧)
    var y0 = d[1], y1 = d[5], y2 = d[9];    // 脸 Y 轴 (脸的头顶)
    var z0 = d[2], z1 = d[6], z2 = d[10];   // 脸 Z 轴 (脸的正面, 朝外)
    var r2d = 180 / Math.PI;
    // 转头 yaw: 脸正面 Z 轴向左/右偏 → 看它在 XZ 平面的方位
    //   ★ 前视摄像头是镜像的: 人头往右转, 画面里脸往左 → 符号取反才是
    //     "照镜子"语义 (和 Live2D 面捕的观感一致)
    var yaw = Math.atan2(z0, z2) * r2d;
    // 点头 pitch: 脸头顶 Y 轴向前/后仰 → 看它的 Z 分量
    var pitch = Math.asin(clamp(y2, -1, 1)) * r2d;
    // 歪头 roll: 脸右侧 X 轴向上/下倾 → 看它的 Y 分量
    var roll = Math.atan2(x1, x0) * r2d;
    return { yaw: yaw, pitch: pitch, roll: roll };
  }

  // ===== 52 blendshapes + 欧拉 → VRM 目标 {expr: weight, head: {yaw,pitch,roll}} =====
  function targets(bs, euler) {
    var t = { expr: {}, head: null };
    // 头角度 (中性校零 + 增益, clamp 到 headMaxDeg)
    if (euler) {
      var n = st._neutral || { yaw: 0, pitch: 0, roll: 0 };
      t.head = {
        yaw: clamp((euler.yaw - n.yaw) * CFG.angleGain, -CFG.headMaxDeg, CFG.headMaxDeg),
        pitch: clamp((euler.pitch - n.pitch) * CFG.angleGain, -CFG.headMaxDeg, CFG.headMaxDeg),
        roll: clamp((euler.roll - n.roll) * CFG.angleGain, -CFG.headMaxDeg, CFG.headMaxDeg)
      };
    }
    var E = t.expr, has = st._idx || {};
    // 眨眼: blink 1=闭 → 权重直接用 (squint 收窄不进眨眼, VRM blink 是闭合量)
    var bl = bs.eyeBlinkLeft || 0, br = bs.eyeBlinkRight || 0;
    var bBoth = (bl + br) / 2;
    if (has.blink) E.blink = clamp(bBoth, 0, 1);
    if (has.blinkLeft) E.blinkLeft = clamp(bl, 0, 1);
    if (has.blinkRight) E.blinkRight = clamp(br, 0, 1);
    // 口型: jawOpen → aa
    if (has.aa) E.aa = clamp(bs.jawOpen || 0, 0, 1);
    // 嘴形: smile/frown → happy / angry (分数峰值偏小, 放大)
    var smi = ((bs.mouthSmileLeft || 0) + (bs.mouthSmileRight || 0)) / 2;
    var fro = ((bs.mouthFrownLeft || 0) + (bs.mouthFrownRight || 0)) / 2;
    if (has.happy) E.happy = clamp((smi - Math.max(fro, 0.1)) * CFG.mouthGain, 0, 1);
    if (has.angry) E.angry = clamp(Math.max(0, (fro - 0.15) * CFG.mouthGain), 0, 1);
    // 眉毛 → surprised (browInnerUp+OuterUp) / sad (browDown)
    var inner = (bs.browInnerUp || 0) + (bs.browOuterUpLeft || 0) * 0.6
              + (bs.browOuterUpRight || 0) * 0.6;
    if (has.surprised) E.surprised = clamp(inner * CFG.browGain * 0.7, 0, 1);
    var bdown = ((bs.browDownLeft || 0) + (bs.browDownRight || 0)) / 2;
    if (has.sad) E.sad = clamp(bdown * CFG.browGain, 0, 1);
    // 视线 → lookLeft/Right/Up/Down (左眼 Out / 右眼 In 同向合成, 带死区)
    var bx = (bs.eyeLookOutLeft || 0) - (bs.eyeLookInLeft || 0)
           + (bs.eyeLookInRight || 0) - (bs.eyeLookOutRight || 0);
    var by = (bs.eyeLookUpLeft || 0) + (bs.eyeLookUpRight || 0)
           - (bs.eyeLookDownLeft || 0) - (bs.eyeLookDownRight || 0);
    bx = bx / 2; by = by / 2;
    if (has.lookLeft && bx > CFG.deadZone) E.lookLeft = clamp(bx, 0, 1);
    if (has.lookRight && bx < -CFG.deadZone) E.lookRight = clamp(-bx, 0, 1);
    if (has.lookUp && by > CFG.deadZone) E.lookUp = clamp(by, 0, 1);
    if (has.lookDown && by < -CFG.deadZone) E.lookDown = clamp(-by, 0, 1);
    return t;
  }

  function ema(key, target, alpha) {
    var s = st._sm;
    if (s[key] === undefined || !isFinite(s[key])) { s[key] = target; return target; }
    s[key] = s[key] + (target - s[key]) * alpha;
    return s[key];
  }

  // ===== 每渲染帧写入 VRM (vrm.js tick 里调; running 时才写) =====
  var _appliedExprs = [];    // 本轮写过的表情名 (停用复位用)
  st.applyFrame = function () {
    if (st.state !== 'running' || !st._vrm) return;
    var bs = st._bs;
    if (!bs || Object.keys(bs).length === 0) return;   // 还没有检测数据
    var t = targets(bs, st.neutralReady ? st._euler : null);
    var em = st._vrm.expressionManager;
    // 表情 (EMA 平滑; 眨眼用更快系数)
    if (em) {
      var next = [];
      for (var name in t.expr) {
        if (!Object.prototype.hasOwnProperty.call(t.expr, name)) continue;
        var v = ema('e_' + name, t.expr[name],
                    /blink/.test(name) ? CFG.blinkSmooth : CFG.smooth);
        try { em.setValue(name, v); next.push(name); } catch (e) {}
      }
      _appliedExprs = next;
    }
    // 头骨 (normalized head quaternion; 中性采集完才接管)
    var head = st._head;
    if (head) {
      if (t.head) {
        var yaw = ema('h_yaw', t.head.yaw, CFG.smooth);
        var pitch = ema('h_pitch', t.head.pitch, CFG.smooth);
        var roll = ema('h_roll', t.head.roll, CFG.smooth);
        if (!st._e3 && global.VRM3D && global.VRM3D.THREE) {
          st._e3 = new global.VRM3D.THREE.Euler(0, 0, 0, 'YXZ');
        }
        if (st._e3) {
          st._e3.set(
            CFG.SIGN_PITCH * pitch * Math.PI / 180,   // 绕 X: 点头
            CFG.SIGN_YAW * yaw * Math.PI / 180,       // 绕 Y: 摇头
            CFG.SIGN_ROLL * roll * Math.PI / 180,     // 绕 Z: 歪头
            'YXZ');
          head.quaternion.setFromEuler(st._e3);
        }
      }
      // 中性采集期间: 不动头 (表情先活起来, 采集完头部再接管)
    }
    st.out = t;
  };

  // ===== 检测循环 (30fps 节流, 与 ffc.js 同款) =====
  function loop() {
    st._raf = requestAnimationFrame(loop);
    var v = st._video;
    if (!v || v.readyState < 2 || !st._landmarker || st.state !== 'running') return;
    var now = performance.now();
    if (now - st._lastTs < CFG.detectInterval) return;
    st._lastTs = now;
    try {
      var res = st._landmarker.detectForVideo(v, now);
      st.frameCount++;
      if (res && res.faceBlendshapes && res.faceBlendshapes.length) {
        st._bs = bsToMap(res.faceBlendshapes[0].categories);
        st._faceLost = false;
      } else {
        st._faceLost = true;   // 丢脸不清空 — 参数冻结 (VTS 语义)
      }
      if (res && res.facialTransformationMatrixes && res.facialTransformationMatrixes.length) {
        st._euler = eulerFromMatrix(res.facialTransformationMatrixes[0].data);
        if (st._euler && !st.neutralReady) {
          st._neutralBuf.push(st._euler);
          if (st._neutralBuf.length >= CFG.neutralFrames) {
            var sy = 0, sp = 0, sr = 0, k;
            for (k = 0; k < st._neutralBuf.length; k++) {
              sy += st._neutralBuf[k].yaw; sp += st._neutralBuf[k].pitch; sr += st._neutralBuf[k].roll;
            }
            var n = st._neutralBuf.length;
            st._neutral = { yaw: sy / n, pitch: sp / n, roll: sr / n };
            st.neutralReady = true;
            log('neutral captured: ' + JSON.stringify(st._neutral));
          }
        }
      }
      st._landmarks = (res && res.faceLandmarks && res.faceLandmarks[0]) || null;
      try { drawFacePreview(st._landmarks); } catch (eD) {}
      st.last = { bs: st._bs, euler: st._euler, frame: st.frameCount };
    } catch (e) {
      log('detect error: ' + (e && e.message || e));
    }
  }

  // video 只喂引擎不显示 (display:none 部分内核停帧 → opacity:0 + 2px 保流)
  function ensureVideo() {
    if (st._video) return st._video;
    var v = document.createElement('video');
    v.id = 'fcVideo';
    v.setAttribute('playsinline', '');
    v.setAttribute('autoplay', '');
    v.muted = true;
    v.style.cssText = 'position:fixed;left:0;top:0;width:2px;height:2px;opacity:0;' +
                      'pointer-events:none;z-index:-1;';
    document.body.appendChild(v);
    st._video = v;
    return v;
  }

  // 隐私预览: 识别关键点连线, 不放用户画面 (照镜子语义 x 镜像)
  function ensureCanvas() {
    if (st._canvas) return st._canvas;
    var box = document.getElementById('fcPreview');
    if (!box) return null;
    var c = document.createElement('canvas');
    c.id = 'fcCanvas';
    c.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;' +
                      'background:#101418;';
    var stt = document.getElementById('fcStatus');
    box.insertBefore(c, stt);
    st._canvas = c;
    st._ctx = c.getContext('2d');
    return c;
  }

  function drawFacePreview(landmarks) {
    var c = st._canvas, ctx = st._ctx;
    if (!c || !ctx) return;
    var w = c.width = c.clientWidth || 118;
    var h = c.height = c.clientHeight || 157;
    ctx.clearRect(0, 0, w, h);
    if (!landmarks || !landmarks.length) {
      ctx.fillStyle = '#5a6a75';
      ctx.font = '10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('未检测到人脸', w / 2, h / 2);
      return;
    }
    var conn = st._contours;
    if (!conn) {
      try { conn = st._contours = global.MPVision.FaceLandmarker.FACE_LANDMARKS_CONTOURS; }
      catch (e) { conn = st._contours = []; }
    }
    ctx.strokeStyle = 'rgba(64, 224, 200, 0.85)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (var i = 0; i < conn.length; i++) {
      var a = landmarks[conn[i].start], b = landmarks[conn[i].end];
      if (!a || !b) continue;
      ctx.moveTo((1 - a.x) * w, a.y * h);
      ctx.lineTo((1 - b.x) * w, b.y * h);
    }
    ctx.stroke();
    var nose = landmarks[1];
    if (nose) {
      ctx.fillStyle = '#ffd166';
      ctx.beginPath();
      ctx.arc((1 - nose.x) * w, nose.y * h, 2.5, 0, 6.284);
      ctx.fill();
    }
  }

  // ===== 模型挂载 (vrm.js 每次加载模型后调) =====
  st.attach = function (vrm) {
    try {
      if (!vrm || !vrm.expressionManager && !vrm.humanoid) return false;
      if (st._vrm === vrm) return true;   // 同模型幂等
      // 换模型: 先复位旧模型被面捕写过的表情与头骨
      if (st._vrm) try { resetCaptureParams(st._vrm); } catch (e0) {}
      st._vrm = vrm;
      st._idx = buildIndex(vrm);
      try {
        st._head = vrm.humanoid ? vrm.humanoid.getNormalizedBoneNode('head') : null;
      } catch (e1) { st._head = null; }
      st._sm = {};
      st._neutral = null;
      st._neutralBuf = [];
      st.neutralReady = false;
      var n = Object.keys(st._idx).length;
      log('attached, expr mapped: ' + n + ', head: ' + !!st._head);
      return n > 0 || !!st._head;
    } catch (e) {
      log('attach fail: ' + (e && e.message || e));
      return false;
    }
  };

  // ===== 启动 (GPU 失败降级 CPU; 资源与 Live2D 面捕完全同款) =====
  async function start() {
    if (st.state === 'running' || st.state === 'starting') return;
    if (!st.supported) {
      setState('error', '此环境不支持摄像头面捕');
      return;
    }
    setState('starting');
    try {
      if (!st._landmarker) {
        var F = global.MPVision;
        var fileset = await F.FilesetResolver.forVisionTasks(CFG.wasmBase);
        var mk = function (delegate) {
          return F.FaceLandmarker.createFromOptions(fileset, {
            baseOptions: { modelAssetPath: CFG.modelPath, delegate: delegate },
            runningMode: 'VIDEO',
            numFaces: 1,
            outputFaceBlendshapes: true,
            outputFacialTransformationMatrixes: true
          });
        };
        try { st._landmarker = await mk('GPU'); }
        catch (eGpu) {
          log('GPU delegate fail, fallback CPU: ' + (eGpu && eGpu.message || eGpu));
          st._landmarker = await mk('CPU');
        }
      }
      var v = ensureVideo();
      if (!st._stream) {
        st._stream = await global.navigator.mediaDevices.getUserMedia({
          audio: false,
          video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } }
        });
      }
      v.srcObject = st._stream;
      await new Promise(function (res) {
        if (v.readyState >= 2) return res();
        v.onloadeddata = res;
        setTimeout(res, 3000);
      });
      try { await v.play(); } catch (eP) {}
      ensureCanvas();
      st._lastTs = 0;
      setState('running');
      cancelAnimationFrame(st._raf);
      st._raf = requestAnimationFrame(loop);
      log('started');
    } catch (e) {
      var msg = e && e.message || String(e);
      if (/Permission|NotAllowed/.test(msg)) msg = '摄像头授权被拒绝';
      else if (/NotFound|DevicesNotFound/.test(msg)) msg = '未找到可用摄像头';
      log('start fail: ' + msg);
      cleanup();
      setState('error', msg);
    }
  }

  // ===== 停止: 流停 + 显式复位 (表情 setValue 0 / head 回 identity) =====
  function resetCaptureParams(vrm) {
    var target = vrm || st._vrm;
    if (!target) return 0;
    var n = 0;
    try {
      var em = target.expressionManager;
      if (em) {
        if (em.resetValues) { try { em.resetValues(); n++; } catch (e0) {} }
        else {
          var names = _appliedExprs;
          for (var i = 0; i < names.length; i++) {
            try { em.setValue(names[i], 0); n++; } catch (e1) {}
          }
        }
      }
    } catch (e2) {}
    try {
      var head = target.humanoid ? target.humanoid.getNormalizedBoneNode('head') : null;
      if (head) { head.quaternion.set(0, 0, 0, 1); n++; }   // identity
    } catch (e3) {}
    return n;
  }

  function cleanup() {
    try { cancelAnimationFrame(st._raf); } catch (e) {}
    st._raf = 0;
    try { if (st._stream) { var ts = st._stream.getTracks(); for (var i = 0; i < ts.length; i++) ts[i].stop(); } } catch (e2) {}
    st._stream = null;
    try { if (st._video) st._video.srcObject = null; } catch (e3) {}
    st._bs = {};
    st._euler = null;
    st._sm = {};
    st._neutral = null;
    st._neutralBuf = [];
    st.neutralReady = false;
    st.out = null;
    st._landmarks = null;
    try { if (st._ctx) st._ctx.clearRect(0, 0, st._canvas.width, st._canvas.height); } catch (e5) {}
    st._faceLost = false;
    try { var nrs = resetCaptureParams(); log('reset: ' + nrs); } catch (e4) {}
    // landmarker 保留 (重开免 wasm/模型重复加载); video 元素保留
  }
  st.start = start;
  st.stop = function () {
    if (st.state === 'idle') return;
    cleanup();
    setState('idle');
    log('stopped');
  };
  st.toggle = function () {
    if (st.state === 'running') st.stop();
    else start();
    return st.state;
  };

  st.getStatus = function () {
    return JSON.stringify({
      state: st.state, error: st.error, supported: st.supported,
      attached: !!st._vrm,
      exprCount: st._idx ? Object.keys(st._idx).length : 0,
      hasHead: !!st._head,
      frames: st.frameCount, neutralReady: st.neutralReady,
      hasBS: Object.keys(st._bs).length > 0,
      out: st.out,
      mpVision: !!(global.MPVision && global.MPVision.FaceLandmarker)
    });
  };

  // 测试钩子注入面: 直接写 _bs/_euler 绕过摄像头验证写入手路径
  // (临时切 running 执行一次 applyFrame, 写完恢复原状态)
  // euler 语义: undefined = 保留当前 (旧行为); null = 显式清空; 对象 = 设置
  st.__inject = function (bs, euler) {
    st._bs = bs || {};
    if (euler === null) st._euler = null;
    else if (euler) st._euler = euler;
    var saved = st.state;
    if (st.state !== 'running') st.state = 'running';
    try { st.applyFrame(); } catch (e) {}
    st.state = saved;
  };

  // ★ v1.1.2: 暴露矩阵分解供测试直调 (三轴解耦回归断言要用真实矩阵路径,
  //   而不是手工构造的伪角度 — 旧 bug 正是"角度语义"理解错才发生的)
  st._eulerFromMatrix = eulerFromMatrix;

  global.VrmFace = st;
})(window);
