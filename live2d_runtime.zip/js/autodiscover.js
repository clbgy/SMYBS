/**
 * ★ v1.2.6: 模型资源自动发现 (AUTODISCOVER)
 *
 * 问题: VTS 导出的模型 (DS 鼠控版等) 的 model3.json 里常常没有
 *   FileReferences.Expressions / FileReferences.Motions 字段 —
 *   因为作者是在 VTS 里用热键挂载表情的, 导出时不写入 settings.
 *   结果: 目录里有 44 个 .exp3.json / 7 个 .motion3.json, 但 Live2D 库
 *   只按 model3.json 索引加载 → 一个都加载不出来 (用户: "有其他形态和表情
 *   等内容, 我们加载不了").
 *
 * 解决: 拦截 settings JSON 加载完成 (settingsJSONLoaded 事件) 到
 *   createModelSettings 之间的窗口, 扫描模型同目录, 把缺失的
 *   Expressions / Motions 补齐; 同时解析 cdi3.json 拿部件的真实中文名与
 *   参数分组, 解析 vtube.json 的 Hotkeys 作为热键元数据.
 *
 * 事件时序 (从 cubism5.min.js 反查确认):
 *   Vt  @40330  e.url=source; emit('settingsJSONLoaded', e)   ← 我们挂这里
 *   Lt  @40536  Gt.findRuntime(source); createModelSettings(source)
 * 两者是 Live2DFactory 中间件数组里相邻的两项, 顺序执行, 所以
 * settingsJSONLoaded 的回调里改 source, 一定能影响后面的 createModelSettings.
 */
(function (global) {
  'use strict';

  var FILE_RE = /\.(exp3\.json|motion3\.json|model3?\.json|cdi3\.json|physics3\.json|vtube\.json)$/i;

  /** 从 settings.url 推出模型所在目录 */
  function dirOf(url) {
    if (!url) return '';
    var s = String(url).split('?')[0].split('#')[0];
    var i = s.lastIndexOf('/');
    return i >= 0 ? s.slice(0, i + 1) : '';
  }

  /**
   * 列出模型目录下的文件名.
   *
   * ★ 首选 Java bridge: WebView 里 fetch 目录 URL 拿不到文件清单 (实测 0 项),
   *   而 App 侧 File.listFiles() 是确定可行的.
   * 降级: 浏览器里开发调试时仍试一次 fetch 目录索引.
   */
  var _bridgeCache = null;

  function bridgeResources() {
    if (_bridgeCache !== null) return _bridgeCache;
    _bridgeCache = false;
    try {
      var b = global.AndroidBridge;
      if (b && typeof b.getModelResources === 'function') {
        var raw = b.getModelResources();
        // ★ v1.2.9: 字符串/对象双兼容 (Java 桥规范返回 String; 对象形态直接用,
        //   防个别 WebView 包装差异 — 也让冒烟 stub 不必模拟序列化)
        var j = null;
        if (raw && raw !== '{}') {
          try { j = (typeof raw === 'string') ? JSON.parse(raw) : raw; } catch (e) { j = null; }
        }
        if (j && Array.isArray(j.files) && j.files.length) {
          _bridgeCache = j;
        }
      }
    } catch (e) {}
    return _bridgeCache;
  }

  /** 重新取一次 bridge 清单 (模型切换后需要) */
  function refreshBridgeResources() {
    _bridgeCache = null;
    return bridgeResources();
  }

  function listModelDir(dir) {
    var br = bridgeResources();
    if (br) return Promise.resolve(br.files.slice());

    // 降级: 目录索引 (静态服务器可能支持)
    return fetch(dir, { headers: { 'Accept': 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        return (j && Array.isArray(j.files)) ? j.files : [];
      })
      .catch(function () { return []; });
  }

  /**
   * ★ v1.2.8: 文件名乱码自愈 (CP437 → UTF-8 还原).
   *
   * 现象: 用户手机上模型目录里的中文名文件显示成 ┬│┌─½∞αΩ 之类的"乱码".
   * 根因: 模型 zip 的文件名**没有打 UTF-8 标记** (实测 DS 包 63 个条目全部
   *   flag_bits&0x800 == 0), 名字字节其实是 UTF-8; 但解压组件 (zip4j 默认/
   *   部分系统解压器) 对无标记条目按 CP437 解码 → 中文变 CP437 图形符.
   * 还原: 乱码是确定性的 — 每个字符查 CP437 表还原成字节, 字节流再按
   *   UTF-8 严格解码即得原中文名. 非乱码名 (ASCII / 真中文) 原样返回.
   */
  // ★ v1.2.9: 表尾原来是普通空格 ' ' — 而 0xFF 在 CP437 里是不可打印的
  //   nbsp, 任何含普通空格的文件名 (如"笑脸 1.exp3.json") 查表时都会被
  //   误映射成 0xFF → UTF-8 strict 解码失败 → 整个名字放弃还原 (用户看到
  //   的乱码里就有这批). 改成真正的 \u00A0 后 round-trip 才无损.
  var CP437_HI = 'ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜ¢£¥₧ƒáíóúñÑªº¿⌐¬½¼¡«»'
               + '░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀'
               + 'αßΓπΣσµτΦΘΩδ∞φε∩≡±≥≤⌠⌡÷≈°∙·√ⁿ²■\u00A0';
  function fixMojibake(s) {
    if (!s || typeof s !== 'string') return s;
    var need = false;
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      // ★ v1.2.9: 检测放宽 — 制表符区 (U+2500 段, charCode > 0x800) 也算
      //   乱码特征. 纯制表符形态的乱码 (旧版解压某些文件名) 之前漏检不还原.
      //   真中文名也会触发 need, 但查表阶段必失败 → 原样返回, 不受影响.
      if (c >= 0x80) { need = true; break; }
    }
    if (!need) return s;                                     // 纯 ASCII / 真 CJK → 原样
    var bytes = [];
    for (var j = 0; j < s.length; j++) {
      var cc = s.charCodeAt(j);
      if (cc < 0x80) { bytes.push(cc); continue; }
      var k = CP437_HI.indexOf(s.charAt(j));
      if (k < 0) return s;                                   // 表外字符 → 不是 CP437 乱码
      bytes.push(0x80 + k);
    }
    try {
      return new TextDecoder('utf-8', { fatal: true }).decode(new Uint8Array(bytes));
    } catch (e) { return s; }
  }

  /**
   * 表情显示名: vtube.json 热键表的中文名优先 (用户按键表里的名字),
   * 文件名(乱码自愈后)兜底.
   * 返回 { 磁盘文件名 → 显示名 } 映射.
   */
  function buildExprNameMap(files) {
    var map = {};
    var hot = {};
    try {
      var br = bridgeResources();
      if (br && Array.isArray(br.hotkeys)) {
        for (var i = 0; i < br.hotkeys.length; i++) {
          var h = br.hotkeys[i];
          if (!h || !h.name) continue;
          // ★ v1.2.9: 热键名本身也可能是乱码 (vtube.json 导出时坏的字节),
          //   之前直接上屏 — 用户看到的"倒问号+制表符"相当一部分是这里.
          //   fixMojibake 对正常中文/ASCII 原样返回, 无害.
          var hname = fixMojibake(String(h.name));
          var hf = String(h.file || '');
          if (!hf || !hname) continue;
          hot[hf] = hname;
          var bn = hf.split('/').pop();       // 全路径 + 纯文件名 双 key
          if (bn && bn !== hf) hot[bn] = hname;
        }
      }
    } catch (e) {}
    for (var k = 0; k < files.length; k++) {
      var raw = String(files[k]);
      if (!/\.exp3\.json$/i.test(raw)) continue;
      var fixed = fixMojibake(raw);
      var base = fixed.replace(/\.exp3\.json$/i, '');
      // 优先级: 热键名(按还原名匹配) > 还原后文件名 > 原文件名
      map[raw] = hot[fixed] || hot[raw] || base || raw;
    }
    return map;
  }

  /**
   * 补 settings: 就地改 settings 对象 (返回改了哪些)
   * @param settings 已 parse 的 model3.json 对象 (带 url 字段)
   * @param files    模型目录下的文件名数组
   */
  function patchSettings(settings, files) {
    var changed = { expressions: 0, motions: 0, rootMotions: 0 };
    if (!settings) return changed;
    var fr = settings.FileReferences || (settings.FileReferences = {});

    // ---------- 1. 表情: 目录下所有 .exp3.json ----------
    var have = {};
    if (Array.isArray(fr.Expressions)) {
      for (var i = 0; i < fr.Expressions.length; i++) {
        var f = fr.Expressions[i] && (fr.Expressions[i].File || fr.Expressions[i].file);
        if (f) have[String(f).toLowerCase()] = 1;
      }
    }
    var exps = files.filter(function (n) { return /\.exp3\.json$/i.test(n); });
    if (exps.length) {
      var nameMap = buildExprNameMap(files);   // ★ v1.2.8: 乱码自愈 + 热键中文优先
      if (!Array.isArray(fr.Expressions)) fr.Expressions = [];
      for (var k = 0; k < exps.length; k++) {
        var name = exps[k];
        if (have[name.toLowerCase()]) continue;
        fr.Expressions.push({ Name: nameMap[name] || name, File: name });
        changed.expressions++;
      }
    }

    // ---------- 2. 动作: motions/ 子目录 (按文件名分组) ----------
    //   motions/ 下的文件 → 组名取文件名去掉 .motion3.json; idle 归到 Idle 组
    //   根目录下的 .motion3.json (如 aidale) → 单文件组
    function isMotion(n) { return /\.motion3\.json$/i.test(n); }
    var subMotions = files.filter(function (n) {
      return n.indexOf('motions/') === 0 && isMotion(n);
    });
    var rootMotions = files.filter(function (n) {
      return n.indexOf('/') < 0 && isMotion(n);
    });

    if (subMotions.length || rootMotions.length) {
      if (!fr.Motions || typeof fr.Motions !== 'object') fr.Motions = {};
      var groups = fr.Motions;

      function ensureGroup(g) {
        if (!Array.isArray(groups[g])) groups[g] = [];
        return groups[g];
      }

      var seen = {};
      for (var key in groups) {
        if (!Object.prototype.hasOwnProperty.call(groups, key)) continue;
        var arr = groups[key];
        if (!Array.isArray(arr)) continue;
        for (var a = 0; a < arr.length; a++) {
          var mf = arr[a] && (arr[a].File || arr[a].file);
          if (mf) seen[String(mf).toLowerCase()] = 1;
        }
      }

      var push = function (group, file) {
        if (seen[file.toLowerCase()]) return false;
        ensureGroup(group).push({ File: file, FadeInTime: 0.5, FadeOutTime: 0.5 });
        seen[file.toLowerCase()] = 1;
        return true;
      };

      for (var s = 0; s < subMotions.length; s++) {
        var rel = subMotions[s];
        var fn = rel.slice('motions/'.length);
        var gname = fn.replace(/\.motion3\.json$/i, '');
        // idle 系列统一进 Idle 组, 便于库自动选待机
        if (/^idle/i.test(gname)) gname = 'Idle';
        if (push(gname, rel)) changed.motions++;
      }
      for (var r2 = 0; r2 < rootMotions.length; r2++) {
        var rm = rootMotions[r2];
        var rgn = rm.replace(/\.motion3\.json$/i, '');
        if (/^idle/i.test(rgn)) rgn = 'Idle';
        if (push(rgn, rm)) changed.rootMotions++;
      }
    }

    // ---------- 3. DisplayInfo 兜底 (部件中文名的来源) ----------
    if (!fr.DisplayInfo) {
      var cdi = files.filter(function (n) { return /\.cdi3\.json$/i.test(n); })[0];
      if (cdi) fr.DisplayInfo = cdi;
    }

    return changed;
  }

  /** 读 JSON (失败返回 null) */
  function readJson(url) {
    return fetch(url).then(function (r) {
      if (!r.ok) throw new Error('http ' + r.status);
      return r.json();
    }).catch(function () { return null; });
  }

  /**
   * 解析 cdi3.json: 取部件中文名 / 参数中文名 / 参数分组
   * 返回 { partNames: {Part48:'恶魔角'}, paramNames:{...}, paramGroups:{...} }
   */
  function parseDisplayInfo(dir, cdiFile) {
    return readJson(dir + cdiFile).then(function (d) {
      var out = { partNames: {}, paramNames: {}, paramGroups: {}, ok: false };
      if (!d) return out;
      try {
        if (Array.isArray(d.Parts)) {
          for (var i = 0; i < d.Parts.length; i++) {
            var p = d.Parts[i];
            if (p && p.Id) out.partNames[p.Id] = p.Name || p.Id;
          }
        }
        if (Array.isArray(d.Parameters)) {
          for (var j = 0; j < d.Parameters.length; j++) {
            var q = d.Parameters[j];
            if (q && q.Id) out.paramNames[q.Id] = q.Name || q.Id;
          }
        }
        if (Array.isArray(d.ParameterGroups)) {
          for (var k = 0; k < d.ParameterGroups.length; k++) {
            var g = d.ParameterGroups[k];
            if (g && g.Id) out.paramGroups[g.Id] = g.Name || g.Id;
          }
        }
        out.ok = true;
      } catch (e) {}
      return out;
    });
  }

  /** 解析 vtube.json: 取 Hotkeys (表情/动作的热键元数据) */
  function parseVtube(dir, files) {
    var vt = files.filter(function (n) { return /\.vtube\.json$/i.test(n); })[0];
    if (!vt) return Promise.resolve({ hotkeys: [], ok: false });
    return readJson(dir + vt).then(function (d) {
      var out = { hotkeys: [], ok: false };
      if (!d) return out;
      try {
        if (Array.isArray(d.Hotkeys)) {
          for (var i = 0; i < d.Hotkeys.length; i++) {
            var h = d.Hotkeys[i];
            if (!h) continue;
            out.hotkeys.push({
              name: h.Name || '',
              action: h.Action || '',
              file: h.File || '',
              active: h.IsActive !== false
            });
          }
        }
        out.ok = true;
      } catch (e) {}
      return out;
    });
  }

  /**
   * 主入口: 接管一次 settings 加载.
   * @param settings 已 parse 的 settings 对象 (会被就地修改)
   * @returns Promise<{changed, display, vtube}>  供调试口读取
   */
  function discover(settings) {
    var dir = dirOf(settings && (settings.url || settings.Url));
    var result = {
      dir: dir, changed: null, display: null, vtube: null, files: 0, ok: false, src: ''
    };
    if (!dir) return Promise.resolve(result);

    var br = bridgeResources();

    return listModelDir(dir).then(function (files) {
      result.files = files.length;
      result.src = br ? 'bridge' : 'fetch';
      result.changed = patchSettings(settings, files);

      // Java 侧已经把 cdi3 / vtube 解析好了 → 直接用 (省一次往返, 且 WebView 里更稳)
      if (br) {
        var vtube = { hotkeys: [], ok: false };
        if (Array.isArray(br.hotkeys)) {
          vtube.hotkeys = br.hotkeys;
          vtube.ok = true;
        }
        result.display = {
          ok: !!(br.partNames && Object.keys(br.partNames).length),
          partNames: br.partNames || {},
          paramNames: br.paramNames || {},
          paramGroups: br.paramGroups || {}
        };
        result.vtube = vtube;
        result.ok = true;
        global.__modelDirInfo = {
          dir: dir,
          partNames: result.display.partNames,
          paramNames: result.display.paramNames,
          paramGroups: result.display.paramGroups,
          hotkeys: vtube.hotkeys,
          // ★ v1.2.10: 表情文件 → 参数 id 表 (取消表情时复位 Add 叠加残留)
          exprParams: br.exprParams || {},
          // ★ v1.2.11: 表情参数定义 (含 Value/Blend) — 多表情叠加引擎按它每帧应用
          exprDefs: br.exprDefs || {}
        };
        return result;
      }

      // 降级: 自己 fetch 解析
      var fr = settings.FileReferences || {};
      var cdi = fr.DisplayInfo;
      return Promise.all([
        cdi ? parseDisplayInfo(dir, cdi) : Promise.resolve({ ok: false }),
        parseVtube(dir, files)
      ]).then(function (arr) {
        result.display = arr[0];
        result.vtube = arr[1];
        result.ok = true;
        global.__modelDirInfo = {
          dir: dir,
          partNames: arr[0].partNames || {},
          paramNames: arr[0].paramNames || {},
          paramGroups: arr[0].paramGroups || {},
          hotkeys: (arr[1].hotkeys || [])
        };
        return result;
      });
    });
  }

  global.ModelAutoDiscover = {
    FILE_RE: FILE_RE,
    dirOf: dirOf,
    listModelDir: listModelDir,
    patchSettings: patchSettings,
    discover: discover,
    install: install,
    refreshBridgeResources: refreshBridgeResources,
    bridgeResources: bridgeResources,
    fixMojibake: fixMojibake,      // ★ v1.2.8: CP437 乱码文件名还原 (调试/其他模块可用)
    /** 最近一次的发现结果 (调试口) */
    last: null
  };

  /**
   * ★ 把自动发现挂进库的加载管线 (Koa 风格中间件, 官方扩展点).
   *
   *   PIXI.live2d.Live2DLoader.middlewares = [xhrLoader]     ← 库自带 1 项
   *   loader: (context, next) => Promise
   *   context = { url, type, target(Live2DModel), result, settings? }
   *
   * 自带的 loader 中间件把 JSON 读进 context.result 就 return, 不调 next()
   * (所以它必须是最后一项). 我们把自定义中间件 unshift 到**最前**:
   *
   *   我们的中间件 (最先跑)
   *     → 先调 next() → 让自带 loader 把 settings JSON 读进 result
   *     → next() resolve 后, 在 createModelSettings 之前补 Expressions/Motions
   *     → 再 return, 管线结束
   *
   * createModelSettings 在 Live2DFactory 的后续中间件里执行, 读的就是被我们
   * 改过的这个对象 → 表情/动作全部可加载. 全程不改库, 不动用户模型文件.
   */
  function install() {
    try {
      var loader = global.PIXI && global.PIXI.live2d && global.PIXI.live2d.Live2DLoader;
      if (!loader || !Array.isArray(loader.middlewares)) return false;
      if (loader.__autodiscoverHooked) return true;

      var mw = function (context, next, index) {
        // 只关心 settings JSON (model3.json / model.json)
        var isSettings = context && context.type === 'json' && typeof context.url === 'string'
          && /model3?\.json$/i.test(context.url.split('?')[0]);
        if (!isSettings) return next();

        return Promise.resolve(next()).then(function () {
          var settings = context.result;
          if (!settings || typeof settings !== 'object') return;
          // 补 url (库后面会赋值, 但我们的 discover 需要它推目录)
          if (!settings.url) settings.url = context.url;
          return discover(settings).then(function (res) {
            global.ModelAutoDiscover.last = res;
            var c = res.changed || {};
            if ((c.expressions || 0) + (c.motions || 0) + (c.rootMotions || 0) > 0) {
              try {
                console.log('[AUTODISCOVER] ' + res.dir
                  + ' 表情+' + c.expressions + ' 动作+' + c.motions + '/' + c.rootMotions
                  + (res.vtube && res.vtube.hotkeys.length
                      ? ' 热键' + res.vtube.hotkeys.length : ''));
              } catch (e) {}
            }
            return undefined;
          }).catch(function (e) {
            try { console.warn('[AUTODISCOVER] fail: ' + (e && e.message || e)); } catch (e2) {}
          });
        }).then(function () {
          // 清理: 让管线后续步骤拿到 settings (library 自带 loader 已放 result)
          return undefined;
        });
      };
      mw.__autodiscover = true;

      loader.middlewares.unshift(mw);
      loader.__autodiscoverHooked = true;
      try { console.log('[AUTODISCOVER] 已挂载 (middlewares=' + loader.middlewares.length + ')'); } catch (e) {}
      return true;
    } catch (e) {
      return false;
    }
  }
})(window);
