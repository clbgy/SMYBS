/**
 * ★ v1.2.6: 表情失灵的真正根因修复 (IDFIX)
 *
 * ===== 现象 =====
 * 桌宠 / 查看器里点任何表情: 接口返回 ok:true, ExpressionManager 也把
 * currentExpression 设上了, 队列里也入了队 —— 但模型纹丝不动.
 * 沙箱实测 (DS 鼠控版): 表情参数 delta = 0, _fadeWeight 恒为 0.
 *
 * ===== 根因: Cubism Core 的 ID 比较用错了类型 =====
 * cubism core 里查参数索引的实现是:
 *     getParameterIndex(t){
 *       for(e=0;e<count;++e) if (t == this._parameterIds.at(e)) return e;
 *       // 找不到 → 当成"不存在的参数", 新建一个幽灵索引返回
 *       return (e = count + this._notExistParameterId.getSize(),
 *               this._notExistParameterId.setValue(t, e),
 *               this._notExistParameterValues.appendKey(e), e);
 *     }
 *
 * 注意那个 **宽松相等 `==`**:
 *   - `this._parameterIds.at(e)` 是 **CubismId 对象** (`{_id:{s:'ParamCheek16'}}`)
 *   - 传进来的 `t` 若是 **字符串** `'ParamCheek16'`
 *     → `'ParamCheek16' == {_id:{...}}` → 右侧没有 valueOf/toString 友好实现
 *     → **永远为 false** → 全部走"幽灵索引"分支.
 *   - 传进来的 `t` 若是 **另一个 CubismId 对象** (表情文件里带的那个)
 *     → 对象比对象, 引用不同 → **同样为 false** → 还是幽灵索引.
 *
 * 实测证据 (DS 鼠控版, 247 个参数):
 *     coreModel.getParameterIndex('ParamCheek16')          -> 247  ← 幽灵!
 *     coreModel.getParameterIndex(表情自带的 CubismId)      -> 189  ← 也是错
 *     正确值应为 189 附近, 而 247 == getParameterCount() (越界)
 *     _notExistParameterId 被污染 size=1
 *
 * 后果链:
 *   1) 表情 doUpdateParameters → addParameterValueById(exprId, v, n)
 *      → getParameterIndex 拿到幽灵索引 → 参数写到 _notExistParameterValues
 *      → 真正的 ParamCheek16 永远是 0 → 表情"哑火".
 *   2) 我们自己的 DiffKit (按字符串 setParameterValueByIndex 前的查表)
 *      以及所有按字符串访问参数的代码, 全都拿到幽灵索引 → 部件/参数
 *      显隐、锁定、组切换全部静默失效.
 *   3) 部件同理: getPartIndex 有一模一样的 bug
 *      → DiffKit 的部件不透明度控制也失效 (实测 snapOpacity 返回 null).
 *
 * ===== 修法 =====
 * 不改库文件. 在拿到 internalModel 后, 给 coreModel 装一层"ID 归一化":
 *   把 getParameterIndex / getPartIndex / *_ById 的入参**先统一成裸字符串**,
 *   再用我们自建的 字符串→索引 映射表查 (映射表由 getParameterId/Id 遍历建立).
 * 这样无论调用方传字符串、CubismId 对象、还是 {_id:{s}} 包装,
 * 都能稳定命中真实索引, 不会再产生幽灵索引.
 */
(function (global) {
  'use strict';

  /** 把任意形态的 CubismId / 字符串 解包成裸字符串 */
  function idStr(o) {
    try {
      if (o === null || o === undefined) return '';
      if (typeof o === 'string') return o;
      // CubismId: {_id:{s:'xxx'}}
      if (o._id !== undefined) {
        var inner = o._id;
        if (inner === null || inner === undefined) return '';
        if (typeof inner === 'string') return inner;
        if (typeof inner === 'object' && inner.s !== undefined) return String(inner.s);
        return String(inner);
      }
      // CubismString: {s:'xxx'}
      if (typeof o === 'object' && o.s !== undefined) return String(o.s);
      return String(o);
    } catch (e) { return ''; }
  }

  /** 建立 字符串→索引 映射 (参数 / 部件) 并缓存到 cm 上 */
  function buildMaps(cm) {
    if (cm.__idfixMaps) return cm.__idfixMaps;
    var maps = { param: {}, part: {} };
    try {
      var pc = cm.getParameterCount();
      for (var i = 0; i < pc; i++) {
        var pid = idStr(cm.getParameterId(i));
        if (pid && maps.param[pid] === undefined) maps.param[pid] = i;
      }
      var nc = cm.getPartCount();
      for (var j = 0; j < nc; j++) {
        var nid = idStr(cm.getPartId(j));
        if (nid && maps.part[nid] === undefined) maps.part[nid] = j;
      }
    } catch (e) {}
    cm.__idfixMaps = maps;
    return maps;
  }

  /**
   * 给 coreModel 打 ID 归一化补丁.
   * 只包装"按 ID 访问"的方法, 按索引访问的方法原样保留.
   */
  function patchCoreModel(cm) {
    if (!cm || cm.__idfix) return false;
    cm.__idfix = true;
    buildMaps(cm);

    // ---- 参数 ----
    var origParamIdx = cm.getParameterIndex;
    cm.getParameterIndex = function (id) {
      var s = idStr(id);
      var m = buildMaps(this).param;
      if (s && m[s] !== undefined) return m[s];
      // 真的不存在 → 交回库处理 (保留其原有语义)
      try { return origParamIdx.call(this, s); } catch (e) { return -1; }
    };

    var origGetById = cm.getParameterValueById;
    if (typeof origGetById === 'function') {
      cm.getParameterValueById = function (id) {
        var i = this.getParameterIndex(id);
        return this.getParameterValueByIndex(i);
      };
    }
    var origSetById = cm.setParameterValueById;
    if (typeof origSetById === 'function') {
      cm.setParameterValueById = function (id, v, w) {
        var i = this.getParameterIndex(id);
        return this.setParameterValueByIndex(i, v, w === undefined ? 1 : w);
      };
    }
    var origAddById = cm.addParameterValueById;
    if (typeof origAddById === 'function') {
      cm.addParameterValueById = function (id, v, w) {
        var i = this.getParameterIndex(id);
        return this.addParameterValueByIndex(i, v, w === undefined ? 1 : w);
      };
    }
    var origMulById = cm.multiplyParameterValueById;
    if (typeof origMulById === 'function') {
      cm.multiplyParameterValueById = function (id, v, w) {
        var i = this.getParameterIndex(id);
        var cur = this.getParameterValueByIndex(i);
        return this.setParameterValueByIndex(i, cur * v, w === undefined ? 1 : w);
      };
    }

    // ---- 部件 ----
    var origPartIdx = cm.getPartIndex;
    if (typeof origPartIdx === 'function') {
      cm.getPartIndex = function (id) {
        var s = idStr(id);
        var m = buildMaps(this).part;
        if (s && m[s] !== undefined) return m[s];
        try { return origPartIdx.call(this, s); } catch (e) { return -1; }
      };
    }
    var origPartOpById = cm.getPartOpacityById;
    if (typeof origPartOpById === 'function') {
      cm.getPartOpacityById = function (id) {
        var i = this.getPartIndex(id);
        return i < 0 ? 0 : this.getPartOpacityByIndex(i);
      };
    }
    var origSetPartOpById = cm.setPartOpacityById;
    if (typeof origSetPartOpById === 'function') {
      cm.setPartOpacityById = function (id, op) {
        var i = this.getPartIndex(id);
        if (i >= 0) this.setPartOpacityByIndex(i, op);
      };
    }

    return true;
  }

  /** 给 internalModel / model 装 (幂等) */
  function patchModel(model) {
    if (!model || !model.internalModel) return false;
    var cm = model.internalModel.coreModel;
    if (!cm) return false;
    var ok = patchCoreModel(cm);
    // 有些版本 coreModel 会整体替换 (reload) → 每帧兜底检查一次
    var im = model.internalModel;
    if (!im.__idfixWatch) {
      im.__idfixWatch = true;
      var origU = im.update;
      if (typeof origU === 'function') {
        im.update = function (dt, now) {
          try {
            var c = this.coreModel;
            if (c && !c.__idfix) patchCoreModel(c);
          } catch (e) {}
          return origU.call(this, dt, now);
        };
      }
    }
    return ok;
  }

  /** 诊断口: 报告关键参数的索引是否正确 (不再越界) */
  function diagnose(model, ids) {
    var out = { paramCount: 0, items: [] };
    try {
      var cm = model.internalModel.coreModel;
      out.paramCount = cm.getParameterCount();
      (ids || []).forEach(function (id) {
        var i = cm.getParameterIndex(id);
        out.items.push({ id: id, index: i, valid: i !== undefined && i >= 0 && i < out.paramCount });
      });
    } catch (e) { out.err = String(e); }
    return out;
  }

  global.IdFix = {
    idStr: idStr,
    patchCoreModel: patchCoreModel,
    patchModel: patchModel,
    buildMaps: buildMaps,
    diagnose: diagnose
  };
})(window);
