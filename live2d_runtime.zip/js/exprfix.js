/**
 * ★ v1.2.6: 表情/动作 应用层修正 (EXPRFIX)
 *
 * 说明: 表情"哑火"的**根因**在 js/idfix.js (Cubism Core 的 ID 宽松相等
 * 比较失败 → 参数被写进幽灵索引). 本文件负责另外两件事:
 *
 *   1) 每帧把"队列条目的时间基"对齐到库当前使用的时间轴
 *      (库 _setExpression 用 performance.now() 毫秒, 而 internalModel.update
 *       传进来的已是秒; 两条时间轴混用会让 updateFadeWeight 算出负的
 *       已流逝时间 → getEasingSine 直接 clamp 到 0).
 *   2) 表情管理器的兜底补挂 (expressionManager 可能是延迟创建的).
 *
 * 两者都必须在 IdFix 之后、DiffKit 之前生效.
 */
(function (global) {
  'use strict';

  var QUEUE_FIELD = '_motions';

  /**
   * 把一条队列条目的时间戳对齐到"库当前使用的秒时间轴".
   * @param entry CubismMotionQueueEntry
   * @param nowSec 本帧库传进来的时间 (秒)
   */
  function alignEntry(entry, nowSec) {
    if (!entry || typeof nowSec !== 'number' || !isFinite(nowSec)) return 0;
    var n = 0;
    try {
      var start = entry.getStartTime();
      var fadeIn = entry.getFadeInStartTime();
      var end = entry.getEndTime();

      // 毫秒时间戳的特征: 明显大于合理秒数, 且与 nowSec*1000 同量级
      var nowMs = nowSec * 1000;
      var looksMs = function (v) {
        return typeof v === 'number' && v > 0 && v > nowSec * 4 && Math.abs(v - nowMs) < nowMs;
      };
      if (looksMs(fadeIn)) { entry.setFadeInStartTime(fadeIn / 1000); n = 1; }
      if (looksMs(start)) { entry.setStartTime(start / 1000); n = 1; }
      if (looksMs(end)) { entry.setEndTime(end / 1000); n = 1; }

      // 对齐后若仍在"未来" → 拉到当前时刻 (语义 ="从现在开始淡入")
      if (entry.getFadeInStartTime() > nowSec) { entry.setFadeInStartTime(nowSec); n = 1; }
      if (entry.getStartTime() > nowSec) { entry.setStartTime(nowSec); n = 1; }
    } catch (e) {}
    return n;
  }

  function alignQueue(q, nowSec) {
    var cnt = 0;
    if (!q) return 0;
    try {
      var v = (typeof q.getCubismMotionQueueEntries === 'function')
        ? q.getCubismMotionQueueEntries() : (q[QUEUE_FIELD] || null);
      if (!v) return 0;
      if (typeof v.getSize === 'function' && typeof v.at === 'function') {
        for (var i = 0; i < v.getSize(); i++) cnt += alignEntry(v.at(i), nowSec);
      } else if (v.length !== undefined) {
        for (var j = 0; j < v.length; j++) cnt += alignEntry(v[j], nowSec);
      }
    } catch (e) {}
    return cnt;
  }

  /** 包装 ExpressionManager.update(coreModel, dt) */
  function patchExpressionManager(em) {
    if (!em || em.__exprFix) return false;
    var orig = em.update;
    if (typeof orig !== 'function') return false;
    em.__exprFix = true;
    em.__exprFixCount = 0;
    em.update = function (coreModel, dt) {
      try {
        var n = alignQueue(this.queueManager, dt);
        if (n) this.__exprFixCount += n;
      } catch (e) {}
      return orig.call(this, coreModel, dt);
    };
    return true;
  }

  /** 给 internalModel 装 (含延迟创建 expressionManager 的兜底) */
  function patchInternalModel(im, label) {
    if (!im || im.__exprFixModel) return false;
    var mm = im.motionManager;
    if (!mm) return false;
    im.__exprFixModel = true;

    var ok = false;
    if (mm.expressionManager) ok = patchExpressionManager(mm.expressionManager);

    if (!mm.__exprFixWatch) {
      mm.__exprFixWatch = true;
      var origMmUpdate = mm.update;
      if (typeof origMmUpdate === 'function') {
        mm.update = function (coreModel, dt) {
          var r = origMmUpdate.call(this, coreModel, dt);
          try {
            if (this.expressionManager && !this.expressionManager.__exprFix) {
              patchExpressionManager(this.expressionManager);
            }
          } catch (e) {}
          return r;
        };
      }
    }
    return ok;
  }

  /** 调试口 */
  function fadeWeightOf(model) {
    try {
      var em = model.internalModel.motionManager.expressionManager;
      if (!em) return null;
      return {
        fadeWeight: em.currentExpression ? em.currentExpression._fadeWeight : null,
        fixCount: em.__exprFixCount || 0,
        patched: !!em.__exprFix,
        reserved: em.reserveExpressionIndex
      };
    } catch (e) { return null; }
  }

  global.ExprFix = {
    patchExpressionManager: patchExpressionManager,
    patchInternalModel: patchInternalModel,
    alignQueue: alignQueue,
    alignEntry: alignEntry,
    fadeWeightOf: fadeWeightOf
  };
})(window);
