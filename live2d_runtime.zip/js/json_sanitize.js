/* json_sanitize.js — 模型 JSON 结构兜底
 * 第三方/转格式模型的 settings JSON 常见"数组字段写成别的类型" (如 Textures 写成
 * 字符串), 库内部直接 .map/.every 崩掉 → 报 "t.map is not a function" 且无法加载.
 * 实测库以 responseType="json" 发起全部 JSON 请求 (浏览器代为 JSON.parse),
 * 所以在 send 时覆盖实例的 response getter: 拿到解析对象后原地修正数组字段
 * (类型错 → 删除让库按缺省走 / 单贴图字符串 → 包成数组 / 单对象 → 包成数组).
 * 文本模式 (responseType="") 同样兜底. 幂等, 二进制 (贴图/音频) 不碰. */
(function () {
  'use strict';
  var RE_JSON = /\.(model3?\.json|pose3?\.json|physics3?\.json|cdi3?\.json|userdata3\.json|exp3?\.json|motion3?\.json)([?#]|$)/i;
  // 必须为数组的字段名 (Cubism 2 小驼峰 / Cubism 3+ 大驼峰混收)
  var ARRAY_KEYS = {
    Textures: 1, textures: 1, Expressions: 1, expressions: 1,
    HitAreas: 1, hit_areas: 1, Groups: 1, Parts: 1, Bindings: 1,
    Visible: 1, Link: 1, Group: 1, group: 1, parts_visible: 1,
    PhysicsRig: 1, Inputs: 1, Outputs: 1, Sections: 1, Vertices: 1,
    physics_hair: 1, Curves: 1, Segments: 1, Parameters: 1,
    ParameterGroups: 1, UserData: 1
  };
  // 容器字段: 自身是对象, 其子键值必须为数组 (Motions/{Idle,TapBody..}, init_param..)
  var CONTAINER_KEYS = { Motions: 1, motions: 1, init_param: 1, init_parts_visible: 1 };

  function fixJson(j, log0) {
    if (!j || typeof j !== 'object' || j.__sanFixed) return;
    function note(m) { if (log0) log0.push(m); }
    for (var k in j) {
      if (!Object.prototype.hasOwnProperty.call(j, k)) continue;
      var v = j[k];
      if (CONTAINER_KEYS[k]) {
        if (v && typeof v === 'object' && !Array.isArray(v)) {
          for (var g in v) {
            if (Object.prototype.hasOwnProperty.call(v, g) &&
                v[g] !== null && typeof v[g] === 'object' && !Array.isArray(v[g])) {
              delete v[g]; note(k + '.' + g + ' removed(non-array)');
            }
          }
        } else if (!v || typeof v !== 'object') { delete j[k]; note(k + ' removed'); }
        continue;
      }
      if (ARRAY_KEYS[k]) {
        if (Array.isArray(v)) {
          for (var i = 0; i < v.length; i++) fixJson(v[i], log0);
        } else if (typeof v === 'string' && (k === 'Textures' || k === 'textures')) {
          j[k] = [v]; note(k + ' string->array');
        } else if (v && typeof v === 'object') {
          j[k] = [v]; note(k + ' object->array');
        } else {
          delete j[k]; note(k + ' removed(type=' + typeof v + ')');
        }
        continue;
      }
      if (v && typeof v === 'object') fixJson(v, log0);
    }
  }

  function normalizeText(raw) {
    if (typeof raw !== 'string' || raw.length < 2) return raw;
    var j;
    try { j = JSON.parse(raw); } catch (e) { return raw; }
    if (!j || typeof j !== 'object') return raw;
    try { fixJson(j); } catch (e) { return raw; }
    try { return JSON.stringify(j); } catch (e) { return raw; }
  }

  function markFixed(obj) {
    try { Object.defineProperty(obj, '__sanFixed', { value: 1, configurable: true }); }
    catch (e) { try { obj.__sanFixed = 1; } catch (e2) {} }
  }

  // 诊断日志 (仅 sanitize 实际生效/失败时打, 静默通过不打): 经 bridge 落 FileLogger
  var _bridge = (window.AndroidBridge && window.AndroidBridge.log)
    ? window.AndroidBridge : { log: function (m) { try { console.log(m); } catch (e) {} } };
  function dbg(m) { try { _bridge.log('[SAN-DBG] ' + m); } catch (e) {} }

  function patchProp(self, proto, prop, mode, url) {
    var d = null;
    try { d = Object.getOwnPropertyDescriptor(proto, prop) ||
               Object.getOwnPropertyDescriptor(self, prop); } catch (e) {}
    if (!d || !d.get || d.configurable === false) {
      dbg('WARN cannot hook ' + prop + ' of ' + url.split('/').pop() +
          ' (desc=' + (d ? 'no-getter/non-configurable' : 'undefined') + ')');
      return;
    }
    try {
      Object.defineProperty(self, prop, {
        configurable: true,
        get: function () {
          var raw = d.get.call(self);
          if (self.readyState !== 4 || raw == null) return raw;
          if (mode === 'json') {
            // Blink 的 response(json) 每次访问可能重新解析出新对象 → 按 XHR 实例缓存修好结果
            if (self.__sanObj === undefined) {
              if (raw && typeof raw === 'object') {
                try {
                  var fixes = [];
                  fixJson(raw, fixes);
                  dbg(url.split('/').pop() + (fixes.length ? ' normalized: ' + fixes.join(', ')
                                                           : ' clean'));
                } catch (e) { dbg('fixJson error on ' + url.split('/').pop() + ': ' + e); }
              }
              self.__sanObj = raw;
            }
            return self.__sanObj;
          }
          // 文本模式: 缓存一次规范化结果, 幂等
          if (self.__sanText === undefined) self.__sanText = normalizeText(raw);
          return self.__sanText;
        }
      });
    } catch (e) {}
  }

  // ===== XHR hook: open 记 URL, send 时按 responseType 分支覆盖 response getter =====
  var proto = XMLHttpRequest.prototype;
  var origOpen = proto.open;
  var origSend = proto.send;
  proto.open = function (method, url) {
    this.__sanUrl = String(url || '');
    return origOpen.apply(this, arguments);
  };
  proto.send = function () {
    var self = this;
    var url = (self.__sanUrl || '').split('?')[0].split('#')[0];
    var rt = self.responseType;
    if (RE_JSON.test(url)) {
      if (rt === 'json') {
        patchProp(self, proto, 'response', 'json', url);
      } else if (rt === '' || rt === 'text') {
        patchProp(self, proto, 'responseText', 'text', url);
        patchProp(self, proto, 'response', 'text', url);
      }
    }
    return origSend.apply(this, arguments);
  };
})();
