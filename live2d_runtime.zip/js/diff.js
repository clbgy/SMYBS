/**
 * DiffKit v1.2.2 — Live2D 差分/部件/表情适配 (桌宠+查看器共用)
 *
 * 背景: 改妆/自制模型的差分 (眼睛/口型/配饰) 多为"部件显隐"机制,
 * 且新旧部件常显叠加 (用户实证: 两种口型重叠, 眨眼时闭眼还能看到眼).
 * 库的 update 流程每帧重写参数与部件透明度, 任何设置必须"每帧锁定":
 *   - 参数锁定: motionManager.update 之后写 (在 coreModel.update 之前 → 变形生效)
 *   - 部件锁定: internalModel.update 之后写 (pose 之后 → 渲染直接生效)
 * 沙箱实测: Mao 锁定 ParamEyeLOpen=0 正确闭眼, 无重叠.
 *
 * 用法: 模型加载完成后 DiffKit.install(model);
 *       之后 App 通过 window.petGetDiffInfo / petSetPartOpacity /
 *       petSetParamLock / petSetExpressionByName / petApplyDiffConfig 操作.
 */
(function (global) {
  'use strict';

  var kit = {
    model: null,
    installed: false,
    paramLocks: {},   // paramId -> value
    paramIndex: {},   // paramId -> coreModel index
    partLocks: {},    // partId -> opacity (0~1)
    partIndex: {},    // partId -> coreModel index
    exprName: null,   // 当前表情名 (v1.2.11 起 = 激活集合里第一个, 兼容旧 UI)
    // ★ v1.2.10: 本轮会话套过的所有表情的参数 id 并集 (取消时复位用)
    exprResetIds: {},
    // ★ v1.2.11: 多表情叠加 (VTS 语义: 多个热键表情同时挂, Add 混合)
    //   exprSet  = { 表情名: {file} }        激活集合
    //   exprDefs = { 文件名: [{id,v,blend}] } 表情参数定义 (Java bridge exprDefs
    //              下发 / fetch 降级), 应用与复位全靠它
    exprSet: {},
    exprDefs: {}
  };

  /** 这个 min.js 的 id getter 返回 {_id:{s:'xx'}} 包装对象, 统一解包 */
  function unwrap(o) {
    try {
      if (o && o._id !== undefined) {
        return (typeof o._id === 'object' && o._id !== null) ? String(o._id.s || '') : String(o._id);
      }
      return String(o);
    } catch (e) { return ''; }
  }

  function buildIndexMaps(cm) {
    kit.paramIndex = {};
    kit.partIndex = {};
    try {
      var pc = cm.getParameterCount(), i, id;
      for (i = 0; i < pc; i++) {
        id = unwrap(cm.getParameterId(i));
        if (id) kit.paramIndex[id] = i;
      }
      var nc = cm.getPartCount();
      for (i = 0; i < nc; i++) {
        id = unwrap(cm.getPartId(i));
        if (id) kit.partIndex[id] = i;
      }
    } catch (e) {}
  }

  /** 每帧: 参数锁定 (motionManager.update 之后调用) */
  function applyParamLocks(cm) {
    var n = 0, k;
    for (k in kit.paramLocks) { n++; break; }
    if (!n || !cm) return;
    for (k in kit.paramLocks) {
      var idx = kit.paramIndex[k];
      if (idx === undefined) continue;
      try { cm.setParameterValueByIndex(idx, kit.paramLocks[k]); } catch (e) {}
    }
  }

  /** 每帧: 部件锁定 (internalModel.update 之后调用) */
  function applyPartLocks(cm) {
    var n = 0, k;
    for (k in kit.partLocks) { n++; break; }
    if (!n || !cm) return;
    for (k in kit.partLocks) {
      var idx = kit.partIndex[k];
      if (idx === undefined) continue;
      try { cm.setPartOpacityByIndex(idx, kit.partLocks[k]); } catch (e) {}
    }
  }

  /** ★ v1.2.10: file → 触发键位 (鼠控/键控热键), 弹窗 chip 标注用 */
  function triggersOf(file) {
    try {
      var di = global.__modelDirInfo;
      var hks = di && di.hotkeys;
      if (!hks) return null;
      var f = String(file || '');
      var ff = global.ModelAutoDiscover && global.ModelAutoDiscover.fixMojibake
        ? global.ModelAutoDiscover.fixMojibake(f) : f;
      for (var i = 0; i < hks.length; i++) {
        var h = hks[i];
        if (!h) continue;
        var hf = String(h.file || '');
        if (hf === f || hf === ff || hf.split('/').pop() === f.split('/').pop()) {
          return Array.isArray(h.triggers) ? h.triggers : null;
        }
      }
    } catch (e) {}
    return null;
  }

  /** 表情列表: 从 model3.json 设置对象读 (库的 settings.expressions) */
  function readExpressions(m) {
    var out = [];
    try {
      var st = m.internalModel.settings;
      var defs = st && (st.expressions || (st.settings && st.settings.expressions));
      if (defs && defs.length) {
        for (var i = 0; i < defs.length; i++) {
          var file = String(defs[i].File || defs[i].file || '');
          var item = { name: String(defs[i].Name || defs[i].name || ('exp_' + i)), file: file };
          var tg = triggersOf(file);
          if (tg && tg.length) item.triggers = tg;
          out.push(item);
        }
      }
    } catch (e) {}
    return out;
  }

  /** 安装: 模型加载完成后调用一次 */
  kit.install = function (m) {
    if (!m || !m.internalModel) return false;
    kit.model = m;
    var im = m.internalModel, cm = im.coreModel, mm = im.motionManager;
    buildIndexMaps(cm);
    kit.paramLocks = {};
    kit.partLocks = {};
    kit.exprName = null;
    kit.exprResetIds = {};   // ★ v1.2.10: 换模型重置 (参数 id 表随模型走)
    kit.exprSet = {};        // ★ v1.2.11: 激活表情集合随模型走
    kit.exprDefs = {};
    if (!kit.installed) {
      kit.installed = true;
      // ★ v1.2.11: 表情全走自管引擎, 库的 expressionManager 必须停用
      //   (它若还挂着旧表情会每帧叠加, 和我们的引擎打架)
      try {
        var em0 = mm && mm.expressionManager;
        if (em0) {
          if (em0.stopAllExpressions) em0.stopAllExpressions();
          em0.currentExpression = em0.defaultExpression || null;
          em0.reserveExpressionIndex = -1;
        }
      } catch (e0) {}
      // ★ v1.2.11: loadParameters AOP — 快照恢复后立刻洗表情残留.
      //   loadParameters 在 mm.update 内部第一步 (恢复上帧快照), 此刻动作
      //   还没写参数 → 洗掉残留后动作得到干净基线 (动作贡献不被吃掉).
      //   ★ v1.2.12 纠正: 拆库实锤这个 fork 的 coreModel.loadParameters
      //   **全库无人调用** (只有 saveParameters 每帧存, 没人恢复) — 快照
      //   恢复实际发生在 motionManager.updateParameters → doUpdateMotion,
      //   v1.2.11 挂 mm.loadParameters 的 AOP 从未生效 (空转). 改挂
      //   updateParameters (动作曲线求值前), 语义一致: 洗完残留动作再写.
      //   机制性收益: 动作不写的表情参数每帧从默认起算, Add 表情不再可能
      //   跨帧累积 (原引擎靠"动作恰好覆盖"兜底, 现在不靠运气).
      if (mm && !mm.__diffLp) {
        mm.__diffLp = true;
        var origLp = mm.updateParameters || mm.loadParameters || null;
        if (origLp) {
          var boundLp = origLp.bind(mm);
          var aopTarget = mm.updateParameters ? 'updateParameters' : 'loadParameters';
          mm[aopTarget] = function (model, dt) {
            var r = boundLp(model, dt);
            try { resetExprParamsFrame(model || (kit.model && kit.model.internalModel.coreModel)); } catch (e4) {}
            return r;
          };
        }
      }
      // 参数锁定 AOP: motionManager.update 之后 (每帧)
      if (mm && !mm.__diffLock) {
        mm.__diffLock = true;
        var origMu = mm.update.bind(mm);
        mm.update = function (model, now) {
          var r = origMu(model, now);
          // ★ v1.2.11: 先叠表情 (官方语义: 表情加在动作之上), 再写用户锁定
          try { applyActiveExpressions(model || (kit.model && kit.model.internalModel.coreModel)); } catch (e5) {}
          try { applyParamLocks(model || (kit.model && kit.model.internalModel.coreModel)); } catch (e) {}
          return r;
        };
      }
      // 部件锁定 AOP: internalModel.update 之后 (pose 已跑完, 渲染前)
      if (im && !im.__diffLock) {
        im.__diffLock = true;
        var origU = im.update.bind(im);
        im.update = function (dt, now) {
          var r = origU(dt, now);
          try { applyPartLocks(cm); } catch (e) {}
          return r;
        };
      }
    }
    return true;
  };

  /** 信息汇总 (App UI 拉取): 部件列表+参数列表+表情列表+当前锁定 */
  kit.info = function () {
    var m = kit.model;
    if (!m) return { ready: false };
    var cm = m.internalModel.coreModel;
    var parts = [], params = [], i, id;
    try {
      var nc = cm.getPartCount();
      for (i = 0; i < nc; i++) {
        id = unwrap(cm.getPartId(i));
        if (!id) continue;
        parts.push({ id: id, op: +Number(cm.getPartOpacityByIndex(i) || 0).toFixed(2),
                     locked: kit.partLocks[id] !== undefined });
      }
      var pc = cm.getParameterCount();
      for (i = 0; i < pc; i++) {
        id = unwrap(cm.getParameterId(i));
        // 只列差分相关参数 (眼睛/口型/形态/腮红), 全量 130+ 参数对用户无意义
        if (/eye|mouth|cheek|brow|form|blush|tear/i.test(id)) {
          params.push({ id: id, v: +Number(cm.getParameterValueByIndex(i) || 0).toFixed(2),
                        min: +Number(cm.getParameterMinimumValue ? (cm.getParameterMinimumValue(i) || 0) : 0).toFixed(2),
                        max: +Number(cm.getParameterMaximumValue ? (cm.getParameterMaximumValue(i) || 1) : 1).toFixed(2),
                        locked: kit.paramLocks[id] !== undefined });
        }
      }
    } catch (e) {}
    return {
      ready: true,
      parts: parts,
      params: params,
      expressions: readExpressions(m),
      exprName: kit.exprName,
      // ★ v1.2.11: 激活表情集合 (多选)
      exprNames: kit.activeNames(),
      paramLocks: kit.paramLocks,
      partLocks: kit.partLocks
    };
  };

  // ===== ★ v1.2.5: 部件分组 (对标按键表.txt 的分层思路: 配件/表情/身体/其他) =====
  //   官方模型部件 id 无分组元数据, 按命名语义猜; 猜不到归 "其他".
  //   分组只影响 App 端展示顺序/分节, 不影响功能.
  var GROUP_RULES = [
    // [组名, 正则]
    ['hair',    /hair|ahoge|ponytail|bang|front|back.?hair|braid|twin/i],
    ['acc',     /glasses|glass|hat|cap|ribbon|bow|earring|necklace|accessor|headphone|mask|crown|flower|sticker|tail|wing|horn|halo|鲸|帽|眼镜|发箍/i],
    ['face',    /eye|brow|mouth|lip|cheek|blush|tear|sweat|face|tongue|teeth|pupil|iris/i],
    ['body',    /body|arm|hand|leg|foot|cloth|dress|skirt|shirt|uniform|shoe|sleeve|tie|scarf|glove/i],
    ['bg',      /bg|background|desk|table|prop|item|effect|shadow|floor|wall|room/i]
  ];

  /** 推断部件分组名 (hair/acc/face/body/bg/other) */
  function guessGroup(partId) {
    if (!partId) return 'other';
    for (var i = 0; i < GROUP_RULES.length; i++) {
      if (GROUP_RULES[i][1].test(partId)) return GROUP_RULES[i][0];
    }
    return 'other';
  }
  kit.guessGroup = guessGroup;

  /** 按分组返回部件 (App 端可据此折叠展示): { hair:[...], acc:[...], ... } */
  kit.partsByGroup = function () {
    var info = kit.info();
    if (!info || !info.ready) return {};
    var out = {};
    for (var i = 0; i < info.parts.length; i++) {
      var p = info.parts[i];
      var g = guessGroup(p.id);
      if (!out[g]) out[g] = [];
      p.group = g;
      out[g].push(p);
    }
    return out;
  };

  /** 部件显隐: op 0~1; op<0 = 解锁该部件 */
  kit.setPart = function (partId, op) {
    if (op < 0) { delete kit.partLocks[partId]; }
    else { kit.partLocks[partId] = Math.max(0, Math.min(1, op));
      try { var idx = kit.partIndex[partId];
        if (idx !== undefined) kit.model.internalModel.coreModel.setPartOpacityByIndex(idx, kit.partLocks[partId]);
      } catch (e) {} }
    return { ok: true, partLocks: kit.partLocks };
  };

  /** 参数锁定: v<0 = 解锁 */
  kit.setParam = function (paramId, v) {
    if (v < 0) { delete kit.paramLocks[paramId]; }
    else { kit.paramLocks[paramId] = v; }
    return { ok: true, paramLocks: kit.paramLocks };
  };

  /** ★ v1.2.10: 把表情动过的参数复位回默认值并重存参数快照.
   *
   * 根因 (拆库实测): Cubism4InternalModel.update 的顺序是
   *   motionManager.update (内含 expression 叠加) → eyeBlink → saveParameters
   * 而 DS 这类 VTS 表情的 Blend 全是 **Add** (相对当前值加) → 叠加值被
   * saveParameters 永久存进参数快照; 下一帧 loadParameters 恢复的就是含
   * 表情的值 → currentExpression 清空后模型上表情照样挂着, 永远洗不掉
   * (实测: 吐舌后 MouthForm -0.5→1, "取消"后仍是 1).
   * 修复: 清表情引用的同时, 把这些参数写回 coreModel 默认值, 再立即
   * saveParameters 覆写快照 — 从根上断掉残留. */
  function resetExprParams() {
    try {
      var cm = kit.model && kit.model.internalModel.coreModel;
      if (!cm) return 0;
      var n = 0;
      for (var pid in kit.exprResetIds) {
        if (!Object.prototype.hasOwnProperty.call(kit.exprResetIds, pid)) continue;
        try {
          var idx = cm.getParameterIndex(pid);
          if (idx === undefined || idx < 0) continue;
          // ★ 注意: coreModel.getParameterDefaultValue(t) 按数组下标取
          //   defaultValues[t] (拆库确认), 传 pid 字符串会得到 undefined
          //   → setParameterValueByIndex(idx, undefined) → 参数变 NaN (首版踩坑).
          cm.setParameterValueByIndex(idx, cm.getParameterDefaultValue(idx));
          n++;
        } catch (e2) {}
      }
      // 复位值必须立刻存进快照 — 否则下一帧 loadParameters 把残留 load 回来
      try { cm.saveParameters(); } catch (e3) {}
      return n;
    } catch (e) { return 0; }
  }

  /** ★ v1.2.10: 记录某表情文件动过的参数 id (供取消时复位).
   *  参数表来自 ModelResources bridge 下发的 exprParams (Java 侧解析 exp3.json). */
  function rememberExprParams(exprFile) {
    try {
      var di = global.__modelDirInfo;
      var map = di && di.exprParams;
      if (!map || !exprFile) return;
      var ids = map[exprFile] || map[fixMojibakeSafe(exprFile)];
      if (Array.isArray(ids)) {
        for (var i = 0; i < ids.length; i++) kit.exprResetIds[ids[i]] = true;
      }
      // ★ v1.2.11: exprDefs 结构 (含 value/blend) 同样累积复位范围
      var dm = di && di.exprDefs;
      var darr = dm && (dm[exprFile] || dm[fixMojibakeSafe(exprFile)]
        || dm[String(exprFile).split('/').pop()]);
      if (Array.isArray(darr)) {
        for (var j = 0; j < darr.length; j++) {
          if (darr[j] && darr[j].id) kit.exprResetIds[darr[j].id] = true;
        }
      }
    } catch (e) {}
  }
  function fixMojibakeSafe(s) {
    try { return (global.ModelAutoDiscover && global.ModelAutoDiscover.fixMojibake) ? global.ModelAutoDiscover.fixMojibake(s) : s; }
    catch (e) { return s; }
  }

  // ===== ★ v1.2.11: 多表情叠加引擎 =====
  // 库的 expressionManager 是单选, 且表情叠加发生在 saveParameters 之前 →
  // Add 型表情被存进参数快照, 永久残留 (v1.2.10 拆库实锤).
  // VTS 的表情本来就是可叠加的 (多个热键表情同时挂).
  // 引擎设计 (每帧):
  //   ① mm.loadParameters AOP: 快照恢复后, 立刻把 exprResetIds 全集写回默认值
  //      — 洗掉快照里的表情残留, 也给动作一个干净的绝对值写入基线;
  //   ② 动作 update (写绝对值, 保留动作对参数的贡献);
  //   ③ mm.update AOP 尾部: 按激活顺序逐个应用表情
  //      (Overwrite=设值 / Add=当前值+v / Multiply=当前值×v) — 官方语义,
  //      表情加在动作结果之上;
  //   ④ im.update 后段自己 saveParameters → 快照="基线+动作+表情",
  //      下一帧 ① 又洗掉 → 无累积, 取消表情下一帧立即消失.
  // 官方库的眨眼在表情后 (会盖表情的眼开闭), 本引擎同序, DS 表情不动眼开闭无冲突.

  /** 表情参数定义: file → [{id, v, blend}]. 优先 Java bridge 的 exprDefs,
   *  没有再 fetch 单个 exp3.json (fetch 目录列不了清单, 但单文件可以). */
  function exprDefsOf(file) {
    var f = String(file || '');
    if (!f) return null;
    var key = f.split('/').pop();
    if (kit.exprDefs[key]) return kit.exprDefs[key];
    try {
      var di = global.__modelDirInfo;
      var defs = di && di.exprDefs;
      var hit = defs && (defs[f] || defs[key]);
      if (hit && hit.length) {
        kit.exprDefs[key] = hit;
        return hit;
      }
    } catch (e) {}
    // 降级: 异步 fetch (下一帧才有, 首次点击可能晚一帧生效 — 可接受)
    loadExprDefAsync(file);
    return null;
  }

  function loadExprDefAsync(file) {
    var f = String(file || '');
    var key = f.split('/').pop();
    if (!key || kit.exprDefs[key] || kit.exprDefs['__fail_' + key]) return;
    try {
      var st = kit.model && kit.model.internalModel.settings;
      var base = st && st.url ? String(st.url).replace(/[^/]*\.json.*$/i, '') : '';
      if (!base) { kit.exprDefs['__fail_' + key] = true; return; }
      // 目录名拼进路径 (modelDirInfo.dir = 模型目录, url 里已含)
      var url = base + f.replace(/^.*\//, '');
      // 带目录: dir + '/' + 文件名 (dirInfo.dir 是目录名)
      try {
        var di = global.__modelDirInfo;
        if (di && di.dir && base.indexOf('/' + di.dir + '/') < 0) url = base + di.dir + '/' + f;
      } catch (e2) {}
      fetch(url).then(function (r) { return r.json(); }).then(function (j) {
        var arr = [];
        var ps = j && (j.Parameters || j.parameters);
        if (ps && ps.length) {
          for (var i = 0; i < ps.length; i++) {
            arr.push({ id: String(ps[i].Id || ps[i].id || ''),
                       v: Number(ps[i].Value !== undefined ? ps[i].Value : ps[i].value) || 0,
                       blend: String(ps[i].Blend || ps[i].blend || 'Add') });
          }
        }
        if (arr.length) kit.exprDefs[key] = arr;
        else kit.exprDefs['__fail_' + key] = true;
      }).catch(function () { kit.exprDefs['__fail_' + key] = true; });
    } catch (e) { kit.exprDefs['__fail_' + key] = true; }
  }

  /** 每帧 (loadParameters 后): 把会话内所有表情参数写回默认值 — 洗残留.
   *  与 v1.2.10 resetExprParams 的区别: 不 saveParameters (快照由 im.update
  *   后段统一存, 存的是洗完+动作+表情的结果). */
  function resetExprParamsFrame(cm) {
    var n = 0;
    for (var pid in kit.exprResetIds) {
      if (!Object.prototype.hasOwnProperty.call(kit.exprResetIds, pid)) continue;
      try {
        var idx = cm.getParameterIndex(pid);
        if (idx === undefined || idx < 0) continue;
        cm.setParameterValueByIndex(idx, cm.getParameterDefaultValue(idx));
        n++;
      } catch (e2) {}
    }
    return n;
  }

  /** 每帧 (动作后): 按激活顺序应用所有激活表情 (VTS 官方语义: 加在动作之上) */
  function applyActiveExpressions(cm) {
    var any = false;
    for (var name in kit.exprSet) {
      if (!Object.prototype.hasOwnProperty.call(kit.exprSet, name)) continue;
      var ef = kit.exprSet[name] && kit.exprSet[name].file;
      var defs = exprDefsOf(ef);
      if (!defs) continue;
      any = true;
      for (var i = 0; i < defs.length; i++) {
        var d = defs[i];
        if (!d || !d.id) continue;
        try {
          var idx = cm.getParameterIndex(d.id);
          if (idx === undefined || idx < 0) continue;
          var blend = String(d.blend || 'Add');
          var cur = cm.getParameterValueByIndex(idx);
          var v;
          if (blend === 'Overwrite') v = d.v;
          else if (blend === 'Multiply') v = cur * d.v;
          else v = cur + d.v;                       // Add (默认)
          // 夹在参数范围内, 防止 Add 越界后引擎 clamp 行为不一致
          var mn = cm.getParameterMinimumValue ? cm.getParameterMinimumValue(idx) : -30;
          var mx = cm.getParameterMaximumValue ? cm.getParameterMaximumValue(idx) : 30;
          cm.setParameterValueByIndex(idx, Math.max(mn, Math.min(mx, v)));
        } catch (e3) {}
      }
    }
    return any;
  }

  /** 激活一个表情: 记录参数表 (复位范围) + 确保定义可用 */
  function activateExpr(name) {
    var st = kit.model && kit.model.internalModel.settings;
    var defs = st && (st.expressions || (st.settings && st.settings.expressions));
    var file = '';
    if (defs) {
      for (var k = 0; k < defs.length; k++) {
        if (String(defs[k].Name || defs[k].name || '') === name) {
          file = String(defs[k].File || defs[k].file || '');
          break;
        }
      }
    }
    kit.exprSet[name] = { file: file };
    if (file) {
      rememberExprParams(file);
      exprDefsOf(file);   // 触发缓存/fetch
    }
  }

  /** toggle: 已激活 → 摘掉, 未激活 → 叠上. 返回 {ok, on, active:[...]} */
  kit.toggleExpression = function (name) {
    var m = kit.model;
    if (!m || !name) return { ok: false, active: kit.activeNames() };
    try {
      if (kit.exprSet[name]) {
        delete kit.exprSet[name];
        // 立即复位该表情参数并覆写快照 — 否则到下一帧洗掉前会闪一帧旧值
        resetExprParams();
      } else {
        activateExpr(name);
      }
      kit.exprName = kit.activeNames()[0] || null;
      return { ok: true, on: !!kit.exprSet[name], active: kit.activeNames() };
    } catch (e) { return { ok: false, err: String(e && e.message || e), active: kit.activeNames() }; }
  };

  /** 全部摘掉 (VTS"按键归位"/"跟随模型") */
  kit.clearExpressions = function () {
    try {
      // 引擎表情管理器一并清 (升级覆盖场景/兜底)
      var em = kit.model && kit.model.internalModel.motionManager.expressionManager;
      if (em) {
        try { if (em.stopAllExpressions) em.stopAllExpressions(); } catch (e1) {}
        try { em.currentExpression = em.defaultExpression || null; em.reserveExpressionIndex = -1; } catch (e2) {}
        try {
          var q = em.queueManager;
          var list = q && (typeof q.getCubismMotionQueueEntries === 'function'
            ? q.getCubismMotionQueueEntries() : (q._motions || null));
          if (list) {
            if (Array.isArray(list)) list.length = 0;
            else if (typeof list.clear === 'function') list.clear();
            else if (list._size !== undefined) { list._size = 0; }
          }
        } catch (e7) {}
      }
      kit.exprSet = {};
      var nres = resetExprParams();
      kit.exprName = null;
      return { ok: true, reset: nres };
    } catch (e) { return { ok: false, err: String(e && e.message || e) }; }
  };

  kit.isActive = function (name) { return !!kit.exprSet[name]; };
  kit.activeNames = function () { return Object.keys(kit.exprSet); };

  /** 表情: name 空/undefined = 全部摘掉; name 给定 = 单选替换 (兼容旧调用,
   *  v1.2.11 UI 全部走 toggleExpression) */
  kit.setExpression = function (name) {
    var m = kit.model;
    if (!m) return { ok: false };
    if (!name) return kit.clearExpressions();
    try {
      // 单选替换: 清空集合再激活这一个 (v1.2.10 及以前的语义)
      if (Object.keys(kit.exprSet).length > 1 || !kit.exprSet[name]) {
        kit.clearExpressions();
        activateExpr(name);
        kit.exprName = name;
        return { ok: true, exprName: name, mode: 'replace' };
      }
      return { ok: true, exprName: name, mode: 'keep' };
    } catch (e) { return { ok: false, err: String(e && e.message || e) }; }
  };

  /** 批量应用 (App 端持久化配置回放): {parts:{id:op}, params:{id:v}, expr:name} */
  kit.applyConfig = function (cfg) {
    if (!cfg) return { ok: false };
    var k;
    if (cfg.parts) for (k in cfg.parts) kit.setPart(k, cfg.parts[k]);
    if (cfg.params) for (k in cfg.params) kit.setParam(k, cfg.params[k]);
    if (cfg.expr !== undefined && cfg.expr !== null) kit.setExpression(cfg.expr);
    return { ok: true };
  };

  kit.reset = function () {
    kit.paramLocks = {};
    kit.partLocks = {};
    kit.setExpression(null);
    kit.exprResetIds = {};
    return { ok: true };
  };

  global.DiffKit = kit;

  // ===== 桌宠 bridge (pet.html 由 App 调用) =====
  global.petGetDiffInfo = function () { return JSON.stringify(kit.info()); };
  global.petSetPartOpacity = function (id, op) { return JSON.stringify(kit.setPart(id, op)); };
  global.petSetParamLock = function (id, v) { return JSON.stringify(kit.setParam(id, v)); };
  global.petSetExpressionByName = function (name) { return JSON.stringify(kit.setExpression(name)); };
  // ★ v1.2.11: 多选叠加入口 (弹窗表情 chips 走这里)
  global.petToggleExpression = function (name) { return JSON.stringify(kit.toggleExpression(name)); };
  global.petClearExpressions = function () { return JSON.stringify(kit.clearExpressions()); };
  global.petApplyDiffConfig = function (json) {
    try { return JSON.stringify(kit.applyConfig(JSON.parse(json))); }
    catch (e) { return JSON.stringify({ ok: false, err: String(e) }); }
  };
  global.petResetDiff = function () { return JSON.stringify(kit.reset()); };
})(window);
