/**
 * Live2D 查看器逻辑 (WebView + PixiJS 8 + pixi-live2d-display)
 *
 * URL 参数:
 *   model      — 模型 json 的虚拟路径 (如 /Hiyori/Hiyori.model3.json, 挂在 /model/ 域下)
 *   theme      — 主题色 (RRGGBB)
 *   legacy     — 1 = Cubism 2 模型 (.model.json), 需先加载 /legacy/live2d.min.js
 *   legacy_ok  — legacy 运行库是否已安装
 *
 * 功能: 双指缩放/拖动, 视线跟随, 点击命中触发动作, 动作/表情点播,
 *       背景切换, 多模型切换, 帧率档 30/60, 截图存相册, 模型信息面板
 */
(function () {
  'use strict';

  // ===== Cubism Core 版本说明 =====
  // 必须使用官方 Cubism 5 core (live2dcubismcore.min.js, r.1+)。
  // 不可升级 core 6: core 6 的 drawables.drawOrders 内存视图在本框架下
  // 返回错误数据(全 500), 会导致 renderOrder 排序错乱、clipping mask
  // 部件(脸/眼/身体)整体不渲染。core 5 原生提供 renderOrders, 无需兼容层。

  // ===== 参数解析 =====
  const qs = new URLSearchParams(location.search);
  const modelParam = qs.get('model') || '';
  const themeColor = '#' + (qs.get('theme') || '5B8DEF');
  const isLegacy = qs.get('legacy') === '1';
  const legacyOk = qs.get('legacy_ok') === '1';

  const bridge = window.AndroidBridge || {
    onReady: function () {}, onError: function (m) { console.error(m); },
    saveScreenshot: function () {}, close: function () {}, log: function (m) { console.log(m); },
    getModelList: function () { return '[]'; },
    setActiveModel: function () {}, getModelResources: function () { return '{}'; }
  };

  // ===== 状态 =====
  const state = {
    app: null,
    model: null,
    modelUrl: null,
    modelLabel: '',
    scaleBase: 1,
    fps: 60,
    drawerSection: null
  };

  // ===== DOM =====
  const $ = function (id) { return document.getElementById(id); };
  const canvas = $('canvas');
  const topbar = $('topbar');
  const drawer = $('drawer');
  const infoPanel = $('infoPanel');

  // ===== 主题色应用到 UI =====
  document.documentElement.style.setProperty('--theme', themeColor);
  const style = document.createElement('style');
  style.textContent = '.chip.on{background:var(--theme)} .btn{color:' + themeColor + '}';
  document.head.appendChild(style);
  // 关闭按钮保持深色可读
  $('btnBack').style.color = '#444';

  // ===== Cubism 2 legacy 加载 =====
  function loadScript(src) {
    return new Promise(function (resolve, reject) {
      const s = document.createElement('script');
      s.src = src;
      s.onload = resolve;
      s.onerror = function () { reject(new Error('加载失败: ' + src)); };
      document.head.appendChild(s);
    });
  }

  // ===== PixiJS 初始化 =====
  async function initApp() {
    const app = new PIXI.Application();
    await app.init({
      canvas: canvas,
      width: window.innerWidth,
      height: window.innerHeight,
      // ★ 显式锁 WebGL (同 pet.html): 防 autoDetect 落到 Canvas 渲染器致库失效
      preference: 'webgl',
      // ★ v1.2.2 背景改 body 层: backgroundAlpha 置 0, 画布永远透明.
      //   原因: Cubism 剪裁上下文每帧会在主画布上额外 clear 一次 (min.js 已
      //   patch 成透明), 若 PIXI 在这里刷不透明底色, 会被那次 clear 整个清掉
      //   → 画布实际透出 WebView 底层. 与其让"PIXI 底色"失效, 不如把背景
      //   色彻底交给 body CSS + WebView 底色, 两边永远一致不再打架.
      backgroundAlpha: 0,
      antialias: true,
      resolution: Math.min(window.devicePixelRatio || 1, 3),
      autoDensity: true,
      powerPreference: 'high-performance'
    });
    app.ticker.maxFPS = state.fps;
    // ★ 物理尺寸 getter 覆盖 (与 pet.html 同款): 库的渲染回调以
    //   `a.width || a.screen?.width` 取 GL viewport, 而 PIXI v8 的 renderer.width
    //   是逻辑尺寸, dpr>1 时模型被画进帧缓冲左下角 1/dpr² 区域 (又小又偏).
    //   覆盖为物理像素后库的自动渲染直接恢复正确.
    var r = app.renderer;
    Object.defineProperty(r, 'width', {
      get: function () { return r.screen.width * r.resolution; }, configurable: true
    });
    Object.defineProperty(r, 'height', {
      get: function () { return r.screen.height * r.resolution; }, configurable: true
    });
    state.app = app;
    window.addEventListener('resize', function () {
      app.renderer.resize(window.innerWidth, window.innerHeight);
      if (state.model) layoutModel(state.model);
    });
  }

  // ===== 模型布局: 居中 + 适配屏幕 =====
  function layoutModel(model) {
    const sw = window.innerWidth;
    const sh = window.innerHeight;
    const mw = model.width;
    const mh = model.height;
    if (!mw || !mh) return;
    const scale = Math.min(sw / mw, sh / mh) * 0.92;
    state.scaleBase = scale;
    model.scale.set(scale * (state._userZoom || 1));
    model.x = sw / 2 + (state._userPanX || 0);
    model.y = sh / 2 + (state._userPanY || 0);
    model.anchor.set(0.5, 0.5);
  }

  // ===== 模型加载 =====
  async function loadModel(url, label) {
    if (isLegacy && !legacyOk && !window.Live2D) {
      bridge.onError('Cubism 2 运行库未安装');
      return;
    }
    showLoadingText();
    try {
      // ★ v1.2.9: 把当前模型相对路径通知 Java (bridge 按它扫描资源清单).
      //   之前查看器的 AndroidBridge 没有 getModelResources, autodiscover
      //   只能 fetch 目录 (WebView 里 0 项) → 表情/动作/部件中文名全部缺失.
      //   不能复用桌宠的固定默认模型逻辑 — 查看器可页内切换多模型.
      try {
        var rel = String(url).split('?')[0].split('#')[0]
          .replace(/^https?:\/\/[^/]+/, '')
          .replace(/^\/model\//, '').replace(/^model\//, '');
        try { rel = decodeURIComponent(rel); } catch (e0) {}
        if (typeof bridge.setActiveModel === 'function') bridge.setActiveModel(rel);
      } catch (e) { bridge.log('setActiveModel fail: ' + e); }
      // ★ v1.2.9: 清 bridge 资源缓存 — 页内切换模型后必须按新目录重取,
      //   否则表情/部件清单还是上一个模型的.
      try {
        if (window.ModelAutoDiscover) window.ModelAutoDiscover.refreshBridgeResources();
      } catch (e) { bridge.log('refreshBridgeResources fail: ' + e); }
      // ★ v1.2.6b: 挂"模型资源自动发现"中间件 (与 pet.html 同源, 幂等可重复调用).
      //   VTS 导出的模型 (如 DS 鼠控版) 的 model3.json 没有 Expressions/Motions
      //   字段 — 之前查看器里表情/动作 chips 直接是空的, 就是缺这一步.
      try {
        if (window.ModelAutoDiscover) window.ModelAutoDiscover.install();
      } catch (e) { bridge.log('autodiscover install fail: ' + e); }
      const model = await PIXI.live2d.Live2DModel.from(url, { ticker: PIXI.Ticker.shared });
      // v8 必需: 显式绑定 renderer (官方 playground 同款)
      if (typeof model.setRenderer === 'function') model.setRenderer(state.app.renderer);
      // ★ v1.1.2 实测必开: 这个库版本 from({ticker}) 的 options 传递有 bug,
      //   autoUpdate 默认值不生效 (探针实测 _seconds 恒 0, 动作不推进/立正).
      //   需两步: 先显式给 ticker (autoUpdate 的 setter 依赖它), 再开 autoUpdate.
      try { model.ticker = PIXI.Ticker.shared; model.autoUpdate = true; } catch (e) {}
      if (state.model) {
        state.app.stage.removeChild(state.model);
        state.model.destroy();
      }
      state.model = model;
      state.modelUrl = url;
      state.modelLabel = label || url.split('/').pop();
      state._userZoom = 1;
      state._userPanX = 0;
      state._userPanY = 0;
      state.app.stage.addChild(model);
      window.__model = model; // DEBUG
      // ★ v1.2.6b: ID 比较 + 表情队列修复 (与 pet.html 同源同序: IdFix → ExprFix → DiffKit).
      //   IdFix 不挂的话 Cubism Core 的 getParameterIndex/getPartIndex 返回越界幽灵索引,
      //   表情/部件点了几十个参数一个都写不进去 — "点了没反应"的真正根因.
      try { if (window.IdFix) window.IdFix.patchModel(model); }
      catch (e) { bridge.log('idfix fail: ' + e); }
      try { if (window.ExprFix) window.ExprFix.patchInternalModel(model.internalModel, 'viewer'); }
      catch (e) { bridge.log('exprfix fail: ' + e); }
      // ★ v1.2.2 差分适配: 同 pet.html 装部件/参数锁定钩子 + window.petGetDiffInfo 等 bridge
      try { if (window.DiffKit) window.DiffKit.install(model); } catch (e) { bridge.log('diff install fail: ' + e); }
      // ★ v1.2.12: 面捕挂载 (AOP updateFocus, 换模型自动重挂; 挂了不等于开着)
      try { if (window.FaceCapture) window.FaceCapture.attach(model); }
      catch (e) { bridge.log('facecapture attach fail: ' + e); }
      // ★ v1.2.6b: 首次进入自动展示工具栏 5 秒.
      //   topbar 平时隐藏 + 无任何提示, "点屏幕呼出"全靠猜 — 表情/部件/动作
      //   入口埋在里面用户根本找不到. 自动亮一次, 图标看得见, 之后照旧短触切换.
      try { hintTopbar(); } catch (e) {}
      layoutModel(model);

      // ===== 运动诊断日志 (落到 FileLogger, 前缀 [VIEW-DBG]) =====
      //  ★ v1.1.2: 补上"动作续播" —— 原来播完一个动作库不再启动新动作,
      //    模型回到立正 (骨骼参数归 0) 并静止, 用户看到的第 4 秒"重置/立正"即此.
      //    查看器是预览器: 播完自动接下一个动作 (随机换组), 保持"活着"的观感.
      window.__viewerPlayNext = function () {
        try {
          const im = model.internalModel;
          const st = im.settings || im;
          const ms = st && st.motions;
          if (!ms) { bridge2.log('[VIEW-DBG] no motions defined'); return; }
          const groups = Object.keys(ms).filter(function (k) {
            return Array.isArray(ms[k]) && ms[k].length;
          });
          if (!groups.length) { bridge2.log('[VIEW-DBG] no motions defined'); return; }
          let g;
          if (groups.length === 1) g = groups[0];
          else {
            for (let i = 0; i < 4; i++) {
              g = groups[Math.floor(Math.random() * groups.length)];
              if (g !== window.__viewerLastGroup) break;
            }
          }
          window.__viewerLastGroup = g;
          const idx = Math.floor(Math.random() * ms[g].length);
          const ok = model.motion(g, idx, 3);
          bridge2.log('[VIEW-DBG] play-next group=' + g + '/' + idx + ' ok=' + ok
                      + ' groups=[' + groups.join(',') + ']');
        } catch (e) {
          bridge2.log('[VIEW-DBG] play-next fail: ' + (e && e.message || e));
        }
      };
      try {
        const im2 = model.internalModel;
        const mm2 = im2.motionManager;
        const bridge2 = window.AndroidBridge || { log: function (m) { console.log(m); } };
        if (mm2 && typeof mm2.on === 'function') {
          mm2.on('motionFinish', function () {
            bridge2.log('[VIEW-DBG] MOTION FINISH at sec=' +
              (mm2._seconds !== undefined ? mm2._seconds.toFixed(2) : '?') + ' → 续播');
            window.__viewerPlayNext();
          });
          bridge2.log('[VIEW-DBG] motionFinish listener attached');
        } else {
          bridge2.log('[VIEW-DBG] motionManager has no .on');
        }
        // ★ 兜底轮换: 循环动作 (元数据 Loop=true) 永不触发 FINISH, 定时强制换
        //   (首启 8 秒后, 之后每次顺延 7~10 秒; 若刚播过 3 秒内则再等)
        var _vLastPlay = 0, _vTimer = null;
        function vRotate(ms) {
          try { if (_vTimer) clearTimeout(_vTimer); } catch (e) {}
          _vTimer = setTimeout(function () {
            try {
              if (!state.model) return;
              if (performance.now() - _vLastPlay < 3000) { vRotate(3000); return; }
              bridge2.log('[VIEW-DBG] fallback rotate');
              window.__viewerPlayNext();
              _vLastPlay = performance.now();
              vRotate(7000 + Math.floor(Math.random() * 3000));
            } catch (e) {}
          }, ms);
        }
        window.__viewerPlayNext = (function (orig) {
          return function () { _vLastPlay = performance.now(); return orig(); };
        })(window.__viewerPlayNext);
        _vLastPlay = performance.now();
        vRotate(8000);
        let hb = 0;
        setInterval(function () {
          try {
            const m = mm2;
            bridge2.log('[VIEW-DBG] HB#' + (hb++) + ' sec=' +
              (m && m._seconds !== undefined ? m._seconds.toFixed(2) : '?') +
              ' currentGroup=' + (m ? m.state && m.state.currentGroup : '?'));
          } catch (e) {}
        }, 2000);
        bridge2.log('[VIEW-DBG] model loaded, motion events attached');
      } catch (e) { bridge.log('[VIEW-DBG] diag setup fail: ' + e); }

      // 点击命中 → 触发对应动作 (库自动 hit-test)
      model.on('hit', function (areas) {
        bridge.log('hit: ' + areas.join(','));
      });

      updateInfoPanel();
      buildMotionChips();
      buildExprChips();
      // ★ v1.2.10: 鼠控/键控热键键盘监听 (幂等)
      try { installHotkeyKeys(); } catch (e) { bridge.log('hotkey keys fail: ' + e); }
      hideLoadingText();
      bridge.onReady();
    } catch (e) {
      hideLoadingText();
      bridge.onError(String(e && e.message || e));
    }
  }

  // ===== 信息面板 =====
  function updateInfoPanel() {
    const m = state.model;
    if (!m) return;
    let cubism = '?';
    try {
      const im = m.internalModel;
      if (im.coreModel && im.coreModel.version) cubism = im.coreModel.version;
      else cubism = isLegacy ? 'Cubism 2' : 'Cubism 3/4/5';
    } catch (e) {}
    const motions = getMotionDefs();
    const exprs = getExprDefs();
    $('infoPanel').innerHTML =
      '<h3>' + escapeHtml(state.modelLabel) + '</h3>' +
      '<div><span class="dim">Size:</span> ' + Math.round(m.width) + ' × ' + Math.round(m.height) + '</div>' +
      '<div><span class="dim">Runtime:</span> ' + cubism + '</div>' +
      '<div><span class="dim">Motions:</span> ' + motions.length + '</div>' +
      '<div><span class="dim">Expressions:</span> ' + exprs.length + '</div>' +
      '<div><span class="dim">FPS:</span> ' + state.fps + '</div>';
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  // ===== 动作/表情定义读取 (直接从 settings 读, Cubism2/4 结构都兼容) =====
  function getMotionDefs() {
    try {
      const s = state.model.internalModel.settings;
      if (s && s.motions) {
        if (Array.isArray(s.motions)) {
          // Cubism 2: [{name, file}, ...]
          return s.motions.map(function (d, i) {
            return { name: d.name || ('Motion ' + (i + 1)), group: '', index: i };
          });
        }
        const out = [];
        Object.keys(s.motions).forEach(function (group) {
          (s.motions[group] || []).forEach(function (d, i) {
            out.push({ name: d.Name || d.name || (group + ' ' + (i + 1)), group: group, index: i });
          });
        });
        return out;
      }
    } catch (e) {}
    return [];
  }
  function getExprDefs() {
    try {
      const s = state.model.internalModel.settings;
      if (s && Array.isArray(s.expressions)) {
        return s.expressions.map(function (d, i) {
          return { name: d.Name || d.name || ('Expression ' + (i + 1)),
                   file: String(d.File || d.file || ''), index: i };
        });
      }
    } catch (e) {}
    return [];
  }

  function motionName(def, i) {
    return (def && def.name) || ('Motion ' + (i + 1));
  }

  function buildMotionChips() {
    const box = $('motionChips');
    box.innerHTML = '';
    const defs = getMotionDefs();
    $('secMotions').style.display = defs.length ? '' : 'none';
    defs.forEach(function (def, i) {
      const chip = document.createElement('div');
      chip.className = 'chip';
      chip.textContent = motionName(def, i);
      chip.onclick = function () {
        playMotion(def, i);
        markChip(box, chip);
      };
      box.appendChild(chip);
    });
  }

  function playMotion(def, i) {
    const m = state.model;
    if (!m) return;
    try {
      m.motion(def.group || undefined, def.index, 3); // 3 = FORCE priority
    } catch (e) {
      bridge.log('motion err: ' + e);
    }
  }

  // ===== ★ v1.2.10 鼠控/键控版热键适配 (VTS Triggers 元数据) =====
  //   DS 这类"鼠控版"模型的热键表 (vtube.json) 里把表情/动作绑到了鼠标和
  //   键盘: Trigger1/2/3 = LeftMouseButton / LeftControl+Z / Alt+B /
  //   Decimal+Numpad2 / PageDown+PageUp(归位) 等. 这里把它们带进查看器:
  //   ① 键盘按下 → 触发对应表情(再按取消)/动作/全部归位;
  //   ② 点击模型本体 → 循环触发"左键组" (VTS 语义: 点模型出反应);
  //   ③ 表情 chip 上标注键位, 用户知道按什么.
  function hotkeysOf() {
    try {
      const di = window.__modelDirInfo;
      return (di && Array.isArray(di.hotkeys)) ? di.hotkeys : [];
    } catch (e) { return []; }
  }

  /** ★ v1.2.11: "操作模仿"开关 (设置页可关) — 关掉后点击模型不触发左键组、
   *  键盘热键不生效. 默认开. 读 App 下发的 inputSpoof (缺字段=开). */
  function spoofEnabled() {
    try {
      if (window.__spoofOn === undefined) {
        const b = window.AndroidBridge || {};
        const raw = b.getAppSettings ? b.getAppSettings() : (b.getSettings ? b.getSettings() : '{}');
        const o = (typeof raw === 'string') ? JSON.parse(raw || '{}') : (raw || {});
        window.__spoofOn = o.inputSpoof !== false;
      }
      return !!window.__spoofOn;
    } catch (e) { return true; }
  }

  /** 键位标注文本: 🖱=鼠标点击, E=单键, Ctrl+Z=组合, Num2=小键盘 */
  function triggerTag(triggers) {
    if (!Array.isArray(triggers) || !triggers.length) return '';
    if (triggers.some(function (t) { return /MOUSEBUTTON/i.test(t); })) return '🖱';
    return triggers.map(function (t) {
      const up = String(t).replace(/^Left|^Right/i, '');
      if (/^Numpad$/i.test(up)) return 'Num';
      if (/^Numpad/i.test(up)) return 'Num' + up.slice(6);
      if (/^Decimal$/i.test(up)) return 'Num.';   // 小键盘小数点键
      return up;
    }).join('+');
  }

  /** ★ 键位归一: VTS 写法 (Alt/LeftControl/Decimal/Numpad2) 与 DOM 事件
   *  (altKey/ControlLeft/NumpadDecimal) 统一到同一域再比较 */
  function normKey(t) {
    const up = String(t).toUpperCase();
    if (/^(ALT|LEFTALT|RIGHTALT)$/.test(up)) return 'ALT';
    if (/^(CONTROL|CTRL|LEFTCONTROL|LEFTCTRL|RIGHTCONTROL|RIGHTCTRL|CONTROLLEFT|CONTROLRIGHT)$/.test(up)) return 'CTRL';
    if (/^(SHIFT|LEFTSHIFT|RIGHTSHIFT|SHIFTLEFT|SHIFTRIGHT)$/.test(up)) return 'SHIFT';
    if (/^DECIMAL$/.test(up)) return 'NUMPADDECIMAL';
    if (/^MULTIPLY$/.test(up)) return 'NUMPADMULTIPLY';
    if (/^ADD$/.test(up)) return 'NUMPADADD';
    if (/^SUBTRACT$/.test(up)) return 'NUMPADSUBTRACT';
    if (/^DIVIDE$/.test(up)) return 'NUMPADDIVIDE';
    return up;
  }

  /** 规范化键盘事件 → ['CTRL','B'] 形式的键位数组 (与 Triggers 同域比较).
   *  ★ held: 当前按住的键表 (installHotkeyKeys 维护) — DOM 的 keydown 事件
   *  只带修饰键状态 (ctrlKey/altKey/...), PageDown+PageUp 这类"双普通键
   *  组合"按住第一个再按第二个时, 第二个事件里根本不知道第一个还按着,
   *  必须自己维护 held 集合并并进画像 (VTS 归位键就是这种). */
  function keyProfile(e, held) {
    const out = [];
    if (e.ctrlKey) out.push('CTRL');
    if (e.altKey) out.push('ALT');
    if (e.shiftKey) out.push('SHIFT');
    let key = String(e.key || '').toUpperCase();
    let code = String(e.code || '').toUpperCase();
    if (key === 'CONTROL' || key === 'ALT' || key === 'SHIFT' || key === 'META') {
      // 修饰键按下本身不算触发键 (防止单按 Ctrl 误触发), 但并入 held 后
      // 组合键仍可匹配 (按住 Ctrl 时再按 Z 的事件自带 ctrlKey)
      return out;
    }
    if (e.metaKey) out.push('META');
    // 字母: KeyZ → Z; 数字行: Digit2 → '2'
    if (/^KEY[A-Z]$/.test(code)) key = code.slice(3);
    const k1 = normKey(key), k2 = normKey(code);
    if (k1 && out.indexOf(k1) < 0) out.push(k1);
    if (k2 && k2 !== k1 && out.indexOf(k2) < 0) out.push(k2);
    // 并入"按住中的键" (双普通键组合的关键路径)
    if (Array.isArray(held)) {
      for (let i = 0; i < held.length; i++) {
        const h = normKey(held[i]);
        if (h && out.indexOf(h) < 0) out.push(h);
      }
    }
    return out;
  }

  /** 键位匹配: 热键的 triggers 全部出现在按键画像里 (顺序无关) */
  function triggersMatch(triggers, profile) {
    if (!Array.isArray(triggers) || !triggers.length) return false;
    return triggers.every(function (t) {
      const up = normKey(t);
      if (/MOUSEBUTTON/.test(up)) return false;             // 鼠标键走点击, 不走键盘
      return profile.indexOf(up) >= 0;
    });
  }

  /** 触发一条热键: 表情 toggle / 动作播放 / 全部归位.
   *  ★ v1.2.11: silent=静默 (点击模型触发时不弹 Toast — 点一下"哔"一条
   *  提示非常吵, 用户截图吐槽的「▶? 鲸鱼喷水」就是它); 表情多选叠加. */
  function fireHotkey(hk, silent) {
    if (!hk || !state.model) return;
    const action = String(hk.action || '');
    const name = String(hk.name || '');
    if (/RemoveAllExpressions/i.test(action) || /归位/.test(name)) {
      try { if (window.DiffKit) DiffKit.clearExpressions(); } catch (e) {}
      refreshExprChipStates();
      if (!silent) toastish('↺ ' + (name || '全部归位'));
      return;
    }
    if (/TriggerAnimation/i.test(action)) {
      // 从 settings.motions 里按文件名找组/序号
      let played = false;
      try {
        const st = state.model.internalModel.settings;
        const ms = st && st.motions;
        if (ms && !Array.isArray(ms)) {
          Object.keys(ms).forEach(function (g) {
            (ms[g] || []).forEach(function (d, i) {
              const f = String(d.File || d.file || '');
              if (!played && (f === hk.file || f.split('/').pop() === String(hk.file || '').split('/').pop())) {
                state.model.motion(g, i, 3);
                played = true;
              }
            });
          });
        }
      } catch (e) {}
      // ★ v1.2.11: 找不到动作不再弹「▶?」— 静默降级 (console 留痕).
      //   之前 VTS 导出的动作组名和热键对不上时, 用户每点一下都看到
      //   莫名其妙的「▶? 鲸鱼喷水」.
      if (played) {
        if (!silent) toastish('▶ ' + name);
      } else {
        try { console.log('[hotkey] 动作未匹配: ' + name + ' file=' + hk.file); } catch (e2) {}
      }
      return;
    }
    // ToggleExpression (默认): 多选叠加 — 已激活的再触发 = 摘掉该表情,
    // 其他保持 (VTS 表情可同时挂多个)
    let isOn = false;
    try {
      if (window.DiffKit) isOn = !!DiffKit.toggleExpression(name).on;
      else { state.model.expression(name); }
    } catch (e) {}
    refreshExprChipStates();
    if (!silent) toastish((isOn ? '✕ ' : '✓ ') + name);
  }

  /** ★ v1.2.11: 按激活集合刷新表情 chips 高亮 (多选: 每个 chip 独立亮灭) */
  function refreshExprChipStates() {
    const box = document.getElementById('exprChips');
    if (!box) return;
    let act = [];
    try { act = (window.DiffKit && DiffKit.activeNames()) || []; } catch (e) {}
    Array.prototype.forEach.call(box.children, function (c) {
      const nm = c.dataset.expr || '';
      c.classList.toggle('on', nm ? act.indexOf(nm) >= 0 : act.length === 0);
    });
  }

  /** 键盘监听 (查看器加载后挂一次).
   *  ★ v1.2.10: 维护"按住中的键"集合 held — 支持双普通键组合
   *  (DS 的按键归位 = PageDown+PageUp). keyup 移除, 失焦/切后台清空
   *  (防止 Alt+Tab 后键卡在 held 里造成误触发); e.repeat 跳过 (按住
   *  不放的自动重复不能反复 toggle 表情). */
  function installHotkeyKeys() {
    if (window.__hotkeyKeysInstalled) return;
    window.__hotkeyKeysInstalled = true;
    const held = [];
    const heldPush = function (e) {
      const key = String(e.key || '').toUpperCase();
      const code = String(e.code || '').toUpperCase();
      if (key && held.indexOf(key) < 0) held.push(key);
      if (code && held.indexOf(code) < 0) held.push(code);
    };
    const heldPop = function (e) {
      const key = String(e.key || '').toUpperCase();
      const code = String(e.code || '').toUpperCase();
      let i = held.indexOf(key); if (i >= 0) held.splice(i, 1);
      i = held.indexOf(code); if (i >= 0) held.splice(i, 1);
    };
    document.addEventListener('keydown', function (e) {
      if (!state.model) return;
      if (!spoofEnabled()) return;              // ★ v1.2.11: 操作模仿开关
      // 输入框聚焦时不抢键
      const tag = (document.activeElement && document.activeElement.tagName) || '';
      if (/INPUT|TEXTAREA/.test(tag)) return;
      if (e.repeat) return;                       // 自动重复: 只认首按
      try { heldPush(e); } catch (e0) {}
      const profile = keyProfile(e, held);
      const hks = hotkeysOf();
      for (let i = 0; i < hks.length; i++) {
        if (triggersMatch(hks[i].triggers, profile)) {
          try { e.preventDefault(); e.stopPropagation(); } catch (e2) {}
          fireHotkey(hks[i]);
          return;
        }
      }
    });
    document.addEventListener('keyup', function (e) {
      try { heldPop(e); } catch (e2) {}
    });
    window.addEventListener('blur', function () { held.length = 0; });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) held.length = 0;
    });
  }

  /** 左键组: 点击模型本体时循环触发 (VTS"点模型出反应"语义)
   *  ★ v1.2.11: 多选叠加 + 点击全程静默 (不弹 Toast) + 开关可关 */
  let _lmbIdx = 0;
  function fireLeftClick() {
    if (!spoofEnabled()) return false;
    const lmb = hotkeysOf().filter(function (h) {
      return Array.isArray(h.triggers) && h.triggers.some(function (t) {
        return /LEFTMOUSEBUTTON/i.test(t);
      });
    });
    if (!lmb.length) return false;
    // 已激活的左键表情 → 再点取消 (多选: 摘掉命中的那一个, 其他保留)
    let act = [];
    try { act = (window.DiffKit && DiffKit.activeNames()) || []; } catch (e) {}
    const curHk = act.length ? lmb.find(function (h) { return act.indexOf(h.name) >= 0; }) : null;
    if (curHk) { fireHotkey(curHk, true); return true; }
    // 循环取下一个 (表情 toggle / 动作播放)
    const hk = lmb[_lmbIdx % lmb.length];
    _lmbIdx = (_lmbIdx + 1) % Math.max(1, lmb.length);
    fireHotkey(hk, true);
    return true;
  }

  function buildExprChips() {
    const box = $('exprChips');
    box.innerHTML = '';
    const defs = getExprDefs();
    $('secExpr').style.display = (defs.length || (window.DiffKit && state.model)) ? '' : 'none';
    const def0 = defs.length ? document.createElement('div') : null;
    // ★ v1.2.11: 多选叠加 — 点 chip = 叠上/摘掉该表情 (可同时多个),
    //   "↺ 无表情" = 一键全摘. 之前单选是照抄 Cubism 引擎的限制,
    //   VTS 的表情本来就是可叠加的 (Add 混合).
    function resetToNone() {
      try { if (window.DiffKit) DiffKit.clearExpressions(); } catch (e) {}
      refreshExprChipStates();
    }
    defs.forEach(function (def) {
      const chip = document.createElement('div');
      chip.className = 'chip';
      // ★ v1.2.10: 键位标注 (鼠控/键控版: 🖱=点模型, [E]/[Ctrl+Z]/[Num2]=按键)
      let label = def.name;
      try {
        const hk = hotkeysOf().find(function (h) {
          const f = String(h.file || '');
          return f === def.file || f.split('/').pop() === def.file.split('/').pop();
        });
        const tag = hk ? triggerTag(hk.triggers) : '';
        if (tag) label = def.name + '  [' + tag + ']';
        chip.dataset.hkName = hk ? hk.name : '';
      } catch (e) {}
      chip.dataset.expr = def.name;   // ★ v1.2.11: 纯名 (label 带键位标注, 匹配要用它)
      chip.textContent = label;
      chip.onclick = function () {
        try {
          if (window.DiffKit) DiffKit.toggleExpression(def.name);
          else state.model.expression(def.name);
        } catch (e) {}
        refreshExprChipStates();
      };
      box.appendChild(chip);
    });
    // "无表情" chip (一键摘掉全部, 之前叫"—"没人看得懂, v1.2.8 改名)
    if (def0) {
      def0.className = 'chip';
      def0.dataset.expr = '';
      def0.textContent = '↺ 无表情';
      def0.title = '清除表情';
      def0.onclick = resetToNone;
      box.appendChild(def0);
    }
    refreshExprChipStates();   // 初始态按激活集合 (多选)
    buildPartToggles();
  }

  /** ★ v1.2.3 部件(配饰)显隐: 每 chip 三态循环 跟随→显示→隐藏 (同桌宠面板)
   *  ★ v1.2.8: chip 文字带状态前缀 (▸显示 / ✕隐藏, 灰=跟随), 一眼分得清;
   *            面板头部加「↺ 全部重置」— 之前点了一堆"显示"叠成怪样子, 没有一键还原. */
  function buildPartToggles() {
    const box = $('partChips');
    if (!box) return;
    box.innerHTML = '';
    const title = $('partsTitle');
    if (!window.DiffKit || !state.model) { if (title) title.style.display = 'none'; return; }
    let info;
    try { info = DiffKit.info(); } catch (e) { return; }
    const parts = (info && info.parts) || [];
    if (!parts.length) { if (title) title.style.display = 'none'; return; }
    if (title) title.style.display = '';
    const stateTag = ['' /*跟随*/, '▸ ' /*显示*/, '✕ ' /*隐藏*/];
    const stateColor = ['#999', '#4CAF50', '#F44336'];
    const allChips = [];
    // ★ v1.2.8: 部件中文显示名 (cdi3.json 的 partNames, 经 bridge 传来).
    //   之前直接显示 "Part162" → 去前缀只剩数字, 用户根本不知道是哪个部件.
    let pn = null;
    try {
      const br = (window.ModelAutoDiscover && window.ModelAutoDiscover.bridgeResources()) || null;
      pn = (br && br.partNames) || null;
    } catch (e) { pn = null; }

    // ★ v1.2.8: 一键还原 — 所有部件回"跟随模型", 所有 chip 回初始态
    const reset = document.createElement('div');
    reset.className = 'chip';
    reset.textContent = '↺ 全部重置';
    reset.style.color = '#FFB300';
    reset.style.borderColor = '#FFB300';
    reset.onclick = function () {
      parts.forEach(function (p) {
        try { DiffKit.setPart(p.id, -1); } catch (e) {}
      });
      allChips.forEach(function (c) {
        c.dataset.state = '0';
        c.textContent = c.dataset.base;
        c.style.color = stateColor[0];
        c.style.borderColor = stateColor[0];
      });
    };
    box.appendChild(reset);

    parts.forEach(function (p) {
      const chip = document.createElement('div');
      chip.className = 'chip';
      // ★ v1.2.8: 显示名优先 cdi3 中文名 (如"鲸鱼"), 数字 id 只做兜底
      const cname = pn ? (pn[p.id] || '') : '';
      const baseName = (cname && cname !== p.id) ? cname : p.id.replace(/^Part/, '');
      chip.dataset.base = baseName;          // ★ v1.2.8: 记住基础名, 前缀随状态换
      chip.title = p.id;                     // 悬停/长按可看原始 id
      chip.textContent = baseName;
      chip.dataset.state = '0';   // 0=跟随 1=显示 2=隐藏
      chip.style.color = '#999';
      allChips.push(chip);
      chip.onclick = function () {
        let st = parseInt(chip.dataset.state, 10);
        st = (st + 1) % 3;
        chip.dataset.state = String(st);
        const op = st === 1 ? 1 : (st === 2 ? 0 : -1);
        try { DiffKit.setPart(p.id, op); } catch (e) {}
        // ★ v1.2.8: 文字 + 颜色双标注 (之前只有颜色, 用户看不出当前是什么状态)
        chip.textContent = stateTag[st] + chip.dataset.base;
        chip.style.color = stateColor[st];
        chip.style.borderColor = stateColor[st];
      };
      box.appendChild(chip);
    });
  }

  function markChip(box, chip) {
    Array.prototype.forEach.call(box.children, function (c) {
      c.classList.remove('on');
    });
    chip.classList.add('on');
  }

  // ===== 多模型列表 =====
  function buildModelChips() {
    let models = [];
    try { models = JSON.parse(bridge.getModelList() || '[]'); } catch (e) {}
    const box = $('modelChips');
    box.innerHTML = '';
    $('secModel').style.display = models.length > 1 ? '' : 'none';
    models.forEach(function (mi) {
      const chip = document.createElement('div');
      chip.className = 'chip';
      chip.textContent = mi.name;
      if (state.modelUrl && state.modelUrl.indexOf(mi.relPath) >= 0) {
        chip.classList.add('on');
      }
      chip.onclick = function () {
        if (isLegacy !== !!mi.legacy) {
          // Cubism 版本不同 → 整页重载 (legacy 运行库需重新初始化)
          location.href = location.pathname + '?model=/' + encodeURIComponent(mi.relPath) +
            '&theme=' + themeColor.replace('#', '') +
            '&legacy=' + (mi.legacy ? 1 : 0) +
            '&legacy_ok=' + (legacyOk ? 1 : 0);
          return;
        }
        loadModel('/model/' + mi.relPath, mi.name);
        markChip(box, chip);
      };
      box.appendChild(chip);
    });
  }

  // ===== 背景切换 =====
  const BG_LIST = [
    ['默认', '#F2F4F8'], ['白', '#FFFFFF'], ['黑', '#1A1A1A'],
    ['粉', '#FFE4EC'], ['蓝', '#E3F2FD'], ['绿', '#E8F5E9'], ['暗紫', '#2B2233']
  ];
  function buildBgSwatches() {
    const box = $('bgColors');
    box.innerHTML = '';
    BG_LIST.forEach(function (bg) {
      const sw = document.createElement('div');
      sw.className = 'swatch';
      sw.style.background = bg[1];
      sw.title = bg[0];
      sw.onclick = function () {
        // ★ v1.2.2 背景色只走 body CSS (画布已透明, body 色直接透出).
        //   旧写法改 renderer.background.color 会被 Cubism 剪裁 clear 清掉 → 永远不生效.
        document.body.style.background = bg[1];
        try { localStorage.setItem('viewer_bg', bg[1]); } catch (e) {}
      };
      box.appendChild(sw);
    });
  }

  // ===== 帧率切换 =====
  function toggleFps() {
    state.fps = state.fps === 60 ? 30 : 60;
    state.app.ticker.maxFPS = state.fps;
    toastish('FPS ' + state.fps);
    updateInfoPanel();
  }

  function toastish(text) {
    let t = $('toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'toast';
      t.style.cssText = 'position:fixed;bottom:15%;left:50%;transform:translateX(-50%);' +
        'background:rgba(0,0,0,.7);color:#fff;padding:8px 18px;border-radius:999px;' +
        'font-size:13px;z-index:99;pointer-events:none;transition:opacity .3s;opacity:0';
      document.body.appendChild(t);
    }
    t.textContent = text;
    t.style.opacity = '1';
    clearTimeout(t._timer);
    t._timer = setTimeout(function () { t.style.opacity = '0'; }, 1200);
  }

  // ===== 截图 =====
  function screenshot() {
    try {
      const c = state.app.renderer.extract.canvas(state.app.stage);
      const url = c.toDataURL('image/png');
      bridge.saveScreenshot(url.split(',')[1]);
    } catch (e) {
      bridge.log('screenshot err: ' + e);
      toastish('Screenshot failed');
    }
  }

  // ===== 加载提示 =====
  function showLoadingText() { toastish('...'); }
  function hideLoadingText() {}

  // ===== 抽屉控制 =====
  const SECTIONS = ['secMotions', 'secExpr', 'secModel', 'secBg'];
  function toggleDrawer(section) {
    if (state.drawerSection === section) {
      drawer.classList.remove('show');
      state.drawerSection = null;
      return;
    }
    SECTIONS.forEach(function (id) {
      $(id).style.display = (id === section) ? '' : 'none';
    });
    drawer.classList.add('show');
    state.drawerSection = section;
  }
  function closeDrawer() {
    drawer.classList.remove('show');
    state.drawerSection = null;
  }

  // ===== 工具栏按钮 =====
  $('btnBack').onclick = function () { bridge.close(); };
  // ★ v1.2.8: 抽屉关闭 — 之前唯一关闭方式是"短触画布", 但抽屉本身盖住画布
  //   (pointer-events:auto), 点抽屉任何地方都不会冒泡到 canvas → 开了就关不掉.
  //   现在: ① 顶部"收起"条 ② 点抽屉空白处 (非 chip) 都能关.
  $('drawerClose').onclick = function () { closeDrawer(); };
  $('drawer').addEventListener('click', function (ev) {
    const t = ev.target;
    if (t.closest('.chip') || t.closest('h4') || t.id === 'drawerClose') return;
    closeDrawer();          // 点在抽屉空白/分区背景上 = 收起
  });
  $('btnMotions').onclick = function () { toggleDrawer('secMotions'); };
  $('btnExpr').onclick = function () { toggleDrawer('secExpr'); };
  $('btnModel').onclick = function () { toggleDrawer('secModel'); };
  $('btnBg').onclick = function () { toggleDrawer('secBg'); };

  // ===== ★ v1.2.12: 面捕开关 + 预览窗 =====
  function fcStatusText() {
    const fc = window.FaceCapture;
    if (!fc) return '';
    if (fc.state === 'starting') return '面捕启动中…';
    if (fc.state === 'error') return ('面捕: ' + (fc.error || '出错')).slice(0, 18);
    if (fc.state === 'running') {
      if (!fc.neutralReady) return '面捕校准中…';
      return '面捕 ' + fc.frameCount + 'f';
    }
    return '面捕';
  }
  function fcSyncUI() {
    const fc = window.FaceCapture;
    if (!fc) return;
    const btn = $('btnFc'), prev = $('fcPreview'), stt = $('fcStatus');
    if (btn) {
      if (fc.state === 'running') btn.classList.add('fcOn');
      else btn.classList.remove('fcOn');
    }
    if (prev) {
      if (fc.state === 'running' || fc.state === 'starting') {
        prev.classList.add('show');
      } else {
        prev.classList.remove('show');
        prev.classList.remove('folded');
      }
    }
    if (stt) stt.textContent = fcStatusText();
  }
  if (window.FaceCapture) {
    window.FaceCapture.on(function (ev) {
      fcSyncUI();
      if (ev && ev.type === 'state') {
        if (ev.state === 'running') toastish('面捕已开启 (1秒内校准头部姿态)');
        else if (ev.state === 'error') toastish('面捕失败: ' + (ev.error || ''));
        else if (ev.state === 'idle') toastish('面捕已关闭');
      }
    });
    // 预览窗点击 = 折叠/展开 (运行中每帧刷新状态文本)
    $('fcPreview').onclick = function () { $('fcPreview').classList.toggle('folded'); };
    setInterval(function () {
      const fc = window.FaceCapture;
      if (fc && (fc.state === 'running' || fc.state === 'starting')) fcSyncUI();
    }, 500);
  }
  $('btnFc').onclick = function () {
    const fc = window.FaceCapture;
    if (!fc || !fc.supported) { toastish('面捕不可用: 摄像头或组件缺失'); return; }
    fc.toggle();
  };
  $('btnFps').onclick = toggleFps;
  $('btnShot').onclick = screenshot;
  $('btnInfo').onclick = function () {
    infoPanel.classList.toggle('show');
  };

  // ===== 手势: 单指拖动 + 双指缩放 + 视线跟随 + tap 显隐工具栏 =====
  const touch = { active: false, startX: 0, startY: 0, moved: false, dist0: 0, zoom0: 1, pinch: false, t0: 0 };

  function onDown(e) {
    if (e.touches && e.touches.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      touch.dist0 = Math.sqrt(dx * dx + dy * dy);
      touch.zoom0 = state._userZoom || 1;
      touch.pinch = true;
      touch.active = true;
      touch.moved = true;
      return;
    }
    touch.active = true;
    touch.pinch = false;
    touch.moved = false;
    touch.startX = (e.touches ? e.touches[0].clientX : e.clientX);
    touch.startY = (e.touches ? e.touches[0].clientY : e.clientY);
    touch.t0 = Date.now();
  }

  function onMove(e) {
    const cx = e.touches ? e.touches[0].clientX : e.clientX;
    const cy = e.touches ? e.touches[0].clientY : e.clientY;
    if (state.model && !touch.pinch) {
      // 视线跟随
      try { state.model.focus(cx, cy); } catch (err) {}
    }
    if (!touch.active || !state.model) return;

    if (touch.pinch) {
      // 双指缩放
      if (e.touches && e.touches.length === 2) {
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (touch.dist0 > 0) {
          const z = Math.min(6, Math.max(0.2, touch.zoom0 * dist / touch.dist0));
          state._userZoom = z;
          state.model.scale.set(state.scaleBase * z);
        }
      }
      return;
    }

    // 单指拖动
    const dx = cx - touch.startX;
    const dy = cy - touch.startY;
    if (Math.abs(dx) + Math.abs(dy) > 12) touch.moved = true;
    if (touch.moved) {
      state._userPanX += (cx - touch.startX);
      state._userPanY += (cy - touch.startY);
      state.model.x += (cx - touch.startX);
      state.model.y += (cy - touch.startY);
      touch.startX = cx;
      touch.startY = cy;
    }
  }

  function onUp() {
    if (touch.active && !touch.moved && !touch.pinch && Date.now() - touch.t0 < 350) {
      const cx = touch.startX, cy = touch.startY;
      // ★ v1.2.10: 点在模型本体上 → 触发"左键组" (VTS 点模型出反应的语义);
      //   点在模型外 → 保持原行为 (切工具栏 / 关抽屉)
      let hitModel = false;
      try {
        hitModel = !!(state.model && state.model.containsPoint
          && state.model.containsPoint({ x: cx, y: cy }));
      } catch (e) { hitModel = false; }
      if (hitModel && fireLeftClick()) return;
      // 短触: 切换工具栏
      if (drawer.classList.contains('show') || infoPanel.classList.contains('show')) {
        closeDrawer();
        infoPanel.classList.remove('show');
      } else {
        topbar.classList.toggle('show');
        // 用户已经会呼出工具栏了 → 取消自动引导的定时收起 (别跟用户抢)
        if (_topbarHintTimer) { clearTimeout(_topbarHintTimer); _topbarHintTimer = null; }
      }
    }
    touch.active = false;
    touch.pinch = false;
  }

  // ★ v1.2.6b: 首次进入自动展示工具栏 5 秒 (发现性引导).
  //   topbar 平时 opacity:0 且无提示, "短触呼出"没人猜得到 → 表情/部件/动作入口
  //   全埋在里面. 模型加载完成后自动亮 5 秒, 图标看得见; 用户短触切换时立即交还控制权.
  let _topbarHintTimer = null;
  function hintTopbar() {
    if (!topbar) return;
    topbar.classList.add('show');
    if (_topbarHintTimer) clearTimeout(_topbarHintTimer);
    _topbarHintTimer = setTimeout(function () {
      // 只在用户还没自己交互时收起 (短触切换处会清掉本 timer)
      if (!_topbarHintTimer) return;
      topbar.classList.remove('show');
      _topbarHintTimer = null;
    }, 5000);
  }

  canvas.addEventListener('touchstart', onDown, { passive: true });
  canvas.addEventListener('touchmove', onMove, { passive: true });
  canvas.addEventListener('touchend', onUp);
  canvas.addEventListener('mousedown', onDown);
  window.addEventListener('mousemove', onMove);
  window.addEventListener('mouseup', onUp);
  // 鼠标滚轮缩放
  canvas.addEventListener('wheel', function (e) {
    if (!state.model) return;
    e.preventDefault();
    const z = Math.min(6, Math.max(0.2, (state._userZoom || 1) * (e.deltaY < 0 ? 1.1 : 0.9)));
    state._userZoom = z;
    state.model.scale.set(state.scaleBase * z);
  }, { passive: false });

  // ===== 启动 =====
  async function boot() {
    topbar.classList.add('show');
    buildBgSwatches();
    // ★ v1.2.2 恢复上次选的背景色 (存于 body CSS, 画布透明后直接透出)
    try {
      const savedBg = localStorage.getItem('viewer_bg');
      if (savedBg) document.body.style.background = savedBg;
    } catch (e) {}
    buildModelChips();
    try {
      await initApp();
    } catch (e) {
      bridge.onError('WebGL init failed: ' + e);
      return;
    }
    if (isLegacy) {
      // Cubism 2 老栈已由 index.html 按需加载; 此处仅校验 legacy 包是否安装
      if (!window.Live2D) {
        bridge.onError('Cubism 2 运行库未安装');
        return;
      }
    }
    if (modelParam) {
      await loadModel('/model' + (modelParam.indexOf('/') === 0 ? '' : '/') + modelParam);
    } else {
      hideLoadingText();
      bridge.onReady();
    }
  }

  boot();
})();
